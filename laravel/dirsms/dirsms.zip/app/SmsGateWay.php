<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmsGateWay extends Model
{  
    protected $table = 'sms_gateways'; 
}
