<?php

namespace App\Http\Controllers;

use App\Communication_user_school_branch;
use Illuminate\Http\Request;

class CommunicationUserSchoolBranchController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\communication_user_school_branch  $communication_user_school_branch
     * @return \Illuminate\Http\Response
     */
    public function show(communication_user_school_branch $communication_user_school_branch)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\communication_user_school_branch  $communication_user_school_branch
     * @return \Illuminate\Http\Response
     */
    public function edit(communication_user_school_branch $communication_user_school_branch)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\communication_user_school_branch  $communication_user_school_branch
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, communication_user_school_branch $communication_user_school_branch)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\communication_user_school_branch  $communication_user_school_branch
     * @return \Illuminate\Http\Response
     */
    public function destroy(communication_user_school_branch $communication_user_school_branch)
    {
        //
    }
}
