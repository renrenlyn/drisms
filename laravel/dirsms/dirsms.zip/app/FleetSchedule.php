<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FleetSchedule extends Model
{
    //
    protected $table = 'fleet_schedules'; 
}
