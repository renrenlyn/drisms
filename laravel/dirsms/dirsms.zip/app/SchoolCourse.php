<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SchoolCourse extends Model
{
    //
    
    protected $table = 'school_course'; 
}
