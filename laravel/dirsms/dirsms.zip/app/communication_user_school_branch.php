<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Communication_user_school_branch extends Model
{
    //
}
