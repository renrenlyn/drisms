<?php 

return [
    'role' => [
        'admin' => "admin",
        'stafff' => "staff", 
        'superadmin' => "superadmin", 
        'instructor' => "instructor", 
        'student' => "student", 
    ], 
    'gender' => [
        'male' => "male",
        'female' => "female", 
    ] 
]; 