 
<?php $__env->startSection('content'); ?>     
        <!-- Admin home page --> 
        <!-- sidebar --> 

    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    

 
  
<!-- main content -->
<div class="main-content">
    <div class="page-header">

    <a href="<?php echo e(route('school.course.add', $id)); ?>" class="btn btn-primary btn-icon pull-right ml-5 <?php echo e($permission_status); ?>" >
        <i class=" mdi mdi-plus-circle-outline">

        </i> 
        Add Course 
    </a>
       
        <h3>List of School Course</h3> 
    </div>
 

    <!-- page content -->
    <div class="row">

        <table class="table table-striped" style="background-color:white;">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">Status</th>
                    <th scope="col">Day</th>
                    <th scope="col">Time</th>
                    <th scope="col">Start</th>
                    <th scope="col">End</th>
                    <th scope="col">Duration</th>
                    <th scope="col">Period</th> 
                    <th scope="col">Action</th> 
                </tr>
            </thead>
            <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $school_corses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>
                        <th scope="row"><?php echo e($key + 1); ?></th>
                        <td><?php echo e($val->name); ?></td> 
                        <td><?php echo e($val->price); ?></td> 
                        <td><?php echo e($val->status); ?></td> 
                        <td>
                            <?php echo e($val->day); ?>  
                        </td> 
                        <td><?php echo e($val->time_start_end); ?></td> 
                        <td><?php echo e($val->start); ?></td> 
                        <td><?php echo e($val->end); ?></td> 
                        <td><?php echo e($val->duration); ?></td> 
                        <td><?php echo e($val->period); ?></td>  
                        <td>  
                            <form id="deleteSC<?php echo e($val->id); ?>" action="<?php echo e(route('school.scDelete', $val->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>  
                                <a  
                                    href="#"  
                                    class="btn btn-danger sc_delete <?php echo e($permission_status); ?> <?php echo e($permission_delete); ?> " 
                                    rel="deleteSC<?php echo e($val->id); ?>"
                                >
                                    <i class="mdi mdi-delete"></i>  
                                </a> 
                            </form>  
                        </td>  
                    </tr> 
 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                    <?php echo $__env->make("admin/empty/empty", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
                <?php endif; ?>
            </tbody>
        </table>


    </div>

</div>  

<?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<script>  
    $('.sc_delete').on('click touchstart', function(e){ 
        e.preventDefault();
        if(confirm("Are you sure to delete this School?")){ 
            $sc_delete = $(this).attr('rel');
            $('#'+$sc_delete).submit();
        } 
    })  
</script>

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/review/reviewCourseSchool.blade.php ENDPATH**/ ?>