<!-- modals -->
<div class="modal right fade" id="update<?php echo e($car->id); ?>" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="mdi mdi-close-circle-outline"></i></span></button>
                    <h4 class="modal-title" id="myModalLabel2">Add Vehicle</h4>
                </div>

                <div class="modal-body">
                    <form action="<?php echo e(route('fleet.update', $car->id)); ?>" method="POST" >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                    <p>A welcome email will be set and recepient will complete setup.</p>
                      <div class="form-group">
                        <div class="row">
                            <div class="col-md-6">
                                <label>Car No.</label>
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    placeholder="Car No." 
                                    name="carno" 
                                    value="<?php echo e($car->car_no); ?>"
                                    required
                                >
           
                            </div>
                            <div class="col-md-6">
                                <label>Number Plate</label>
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    placeholder="Number Plate" 
                                    name="carplate" 
                                    required
                                    value="<?php echo e($car->car_plate); ?>"
                                >
                            </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="row">
                            <div class="col-md-6">
                                <label>Make</label>
                                <input 
                                    type="text"
                                    class="form-control" 
                                    placeholder="Make" 
                                    name="make" 
                                    required
                                    value="<?php echo e($car->make); ?>"
                                >
                              </div>
                            <div class="col-md-6">
                                <label>Model</label>
                                <input 
                                    type="text"
                                    class="form-control" 
                                    placeholder="Model" 
                                    name="model" 
                                    required
                                    value="<?php echo e($car->model); ?>"
                                >
                              </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <label>Model Year</label>
                                <input 
                                    type="number" 
                                    class="form-control" 
                                    placeholder="Model Year" 
                                    name="modelyear" 
                                    required
                                    value="<?php echo e($car->model_year); ?>" 
                                >
                            </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <label for="email">Assigned Instructor</label>
                                
                                <select class="form-control select" name="instructor" required> 
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option class="item" value="<?php echo e($user->id); ?>"><?php echo e($user->fname); ?> <?php echo e($user->lname); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                            
                                <input type="submit" value="Update Vehicle" class="btn btn-primary btn-block">
                                <!-- <button class="btn btn-primary btn-block" type="submit">Add Vehicle</button>
                            -->
                            </div>
                        </div>
                      </div>
                      
                    </form>
                </div>

            </div><!-- modal-content -->
        </div><!-- modal-dialog -->
    </div><!-- modal -->

    <!-- update -->
    <div class="modal right fade" id="update" role="dialog" tabindex="-1">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button aria-label="Close" class="close" data-dismiss="modal" type="button"><span aria-hidden="true"><i class="mdi mdi-close-circle-outline"></i></span></button>
                    <h4 class="modal-title" id="myModalLabel2">Edit Car</h4>
                </div>
                <div class="update-holder"></div>
            </div><!-- modal-content -->
        </div><!-- modal-dialog -->
    </div>
    <!-- end update --><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/modified/fleet.blade.php ENDPATH**/ ?>