 
<?php $__env->startSection('content'); ?>      
    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     

    <style>

        ul li{
            list-style: none;
        }
        .form-drisms tbody tr td{
            padding-top: 0px !important; 
            padding-bottom: 0px !important
        }
        .form-drisms tbody tr{
            background-color:white !important;
        }
    </style>
<div class="main-content"> 
    <div class="page-header"> 
        <h3>School</h3>
    </div> 


    <!-- students growth -->
    <div class="row">  
        <?php $__empty_1 = true; $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5><?php echo e($school->name); ?> ( School )</h5> 
                        <small><?php echo e($school->address); ?></small>
                    </div>  
                    <div class="card-body p-0">
                        <div class="row">
                            <div class="col-md-12 growth-left"> 
                                <?php $__empty_2 = true; $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?> 
                                    <?php if($branch->school_id == $school->id): ?> 
                                        <h5><?php echo e($branch->name); ?> ( Branch )</h5> 
                                        <small><?php echo e($branch->address); ?></small>  
                                        <?php 
                                            $branches_id = $branch->id;
                                        ?>
                                        <?php echo $__env->make("student/view/theoretical_form", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                                    <?php endif; ?> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>  
                                    <?php 
                                        $branches_id = NULL;
                                    ?> 
                                        <?php echo $__env->make("student/view/theoretical_form", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?> 
                                        
                            </div>
                            <div class="col-md-6">
                                <div class="student-growth-chart mt-15"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php echo $__env->make("admin/empty/empty", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
        <?php endif; ?> 
    </div> 
</div>


<?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

<script>
    $('.ec_forn_c').on('change', function(){
     
            $('.ec_forn_c').not(this).prop('checked',false);  
            $data = $(this).attr('rel');
            
            $('.dc-cls').addClass('hidden'); 
            $('#'+$data).removeClass('hidden'); 
         
    });

    $('.others_mc').on('change', function(){

        if($(this).is(":checked")){ 
            $('.other-transmission').removeClass('hidden');
        }else{

            $('.other-transmission').addClass('hidden');
        }
    })

    $('.others_').on('change', function(){

        if($(this).is(":checked")){ 
            $('.other_inform').removeClass('hidden');
        }else{

            $('.other_inform').addClass('hidden');
        }
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/student/schedule_theoretical.blade.php ENDPATH**/ ?>