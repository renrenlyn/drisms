 
<?php $__env->startSection('content'); ?>     
        <!-- Admin home page --> 
        <!-- sidebar --> 

    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

    <!-- main content -->
    <div class="main-content">
        <div class="page-header">
            <button type="button" class="btn btn-success btn-icon pull-right ml-5"  data-toggle="modal" data-target="#sendemail"><i class=" mdi mdi-email-outline"></i> Send Email </button>
            <button type="button" class="btn btn-primary btn-icon pull-right"  data-toggle="modal" data-target="#sendsms"><i class=" mdi mdi-message-text-outline"></i> Send SMS </button>
            <h3>Communication</h3>
        </div>

        <?php if( \Session::has('success')): ?>
            <div class="alert alert-success"> 
                <?php echo \Session::get('success'); ?>

            </div>
        <?php endif; ?> 
        
        <?php if( \Session::has('error')): ?>
            <div class="alert alert-danger"> 
                <?php echo \Session::get('error'); ?>

            </div>
        <?php endif; ?> 
        <!-- page content -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body p-0 " id="communication-content">

                        <ul class="nav nav-tabs" id="communication">
                            <li>
                                <a href="" class="active" rel="to-users">
                                    To Users
                                </a>
                            </li>
                            <li>
                                <a href="#" rel="to-branches">
                                    To Branches
                                </a>
                            </li> 
                            <li>
                                <a href="#" rel="to-schools">
                                    To Schools
                                </a>
                            </li> 
                        </ul>
 
                        <div class="table-responsive hidden d-block" id="to-users" style="height: 100vh">
                            <table class="table table-striped mb-0 mw-1000" id="data-table">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Receiver Users</th>
                                    <th>Status + Date</th>
                                    <th>Message</th>
                                    <th class="text-center">Action</th>
                                </tr>
                                </thead>
                                <tbody> 

                                    <?php $__empty_1 = true; $__currentLoopData = $receiver_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                    <?php echo $__env->make("admin/read/communication", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                                    <tr>
                                        <th scope="row"><?php echo e($key + 1); ?></th>
                                        <td> 
                                            <?php if($value->image_name): ?>
                                                <img 
                                                    src="<?php echo e(url('/images'). '/' .$value->image_name); ?> " 
                                                    class="table-avatar communication-avatar img-responsive" 
                                                >   
                                            <?php else: ?>
                                                <img 
                                                    src="<?php echo e(url('/assets/images/avatar.png')); ?> " 
                                                    class="table-avatar communication-avatar img-responsive" 
                                                > 
                                            <?php endif; ?>  
                                            <a href=""><strong><?php echo e($value->fname); ?> <?php echo e($value->lname); ?></strong></a> 
                                            <span class="communication-contact"><?php echo e($value->phone); ?></span> 
                                            <span class="badge badge-primary"><?php echo e($value->type); ?></span>  
                                        </td>
                                        <td>
                                        <?php echo e(Str::limit($value->messages, 30)); ?>

                                        </td>
                                        <td class="text-center">
                                            <button 
                                                class="btn btn-primary btn-sm btn-icon"  
                                                data-toggle="modal"
                                                data-target="#read_message<?php echo e($value->id); ?>"
                                            >
                                                <i class=" mdi mdi-email-outline"></i>  
                                                Read Message
                                            </button>

                                            <form class="d-inline" action="<?php echo e(route('communication.destroy', $value->cusb_id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>  

                                                <button class="btn btn-danger btn-sm d-inline" type="submit">
                                                    <i class="mdi mdi-delete"></i>
                                                </button>
                                        
                                            </form>
                                            
                                        </td>
                                    </tr> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <th colspan="7">
                                                <p class="text-muted text-center">
                                                    It's empty here.
                                                </p>
                                            </th>
                                        </tr> 
                                    <?php endif; ?>
 
                                </tbody>
                            </table>
                        </div>


                        <div class="table-responsive hidden" id="to-branches"  style="height: 100vh">
                            <table class="table table-striped mb-0 mw-1000" id="data-table">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Receiver branches</th>
                                    <th>Status + Date</th>
                                    <th>Message</th>
                                    <th class="text-center">Action</th>
                                </tr>
                                </thead>
                                <tbody> 
                                    <?php $__empty_1 = true; $__currentLoopData = $branch_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                        <?php echo $__env->make("admin/read/communication", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                                        <tr>
                                            <th scope="row"><?php echo e($key + 1); ?></th>
                                            <td>  
                                                <a href=""><strong><?php echo e($value->name); ?> </strong></a> 
                                                <span class="communication-contact"><?php echo e($value->phone); ?></span> 
                                                <span class="badge badge-primary"><?php echo e($value->type); ?></span>  
                                            </td>
                                            <td>
                                            <?php echo e(Str::limit($value->messages, 30)); ?>

                                            </td>
                                            <td class="text-center">
                                                <button 
                                                    class="btn btn-primary btn-sm btn-icon"  
                                                    data-toggle="modal"
                                                    data-target="#read_message_<?php echo e($value->id); ?>"
                                                >
                                                    <i class=" mdi mdi-email-outline"></i>  
                                                    Read Message
                                                </button>

                                                
                                                
                                            <form class="d-inline" action="<?php echo e(route('communication.destroy', $value->cusb_id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>  

                                                <button class="btn btn-danger btn-sm d-inline" type="submit">
                                                    <i class="mdi mdi-delete"></i>
                                                </button>
                                        
                                            </form>
                                            </td>
                                        </tr> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <th colspan="7">
                                                    <p class="text-muted text-center">
                                                        It's empty here.
                                                    </p>
                                                </th>
                                            </tr> 
                                        <?php endif; ?>

                                </tbody>
                            </table>
                        </div>
                        <div class="table-responsive hidden" id="to-schools" style="height: 100vh"> 
                            <table class="table table-striped mb-0 mw-1000" id="data-table">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Receiver schools</th>
                                    <th>Status + Date</th>
                                    <th>Message</th>
                                    <th class="text-center">Action</th>
                                </tr>
                                </thead>
                                <tbody> 
                                    <?php $__empty_1 = true; $__currentLoopData = $school_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                        <?php echo $__env->make("admin/read/communication", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                                        <tr>
                                            <th scope="row"><?php echo e($key + 1); ?></th>
                                            <td>  
                                                <a href=""><strong><?php echo e($value->name); ?> </strong></a> 
                                                <span class="communication-contact"><?php echo e($value->phone); ?></span> 
                                                <span class="badge badge-primary"><?php echo e($value->type); ?></span>  
                                            </td>
                                            <td>
                                            <?php echo e(Str::limit($value->messages, 30)); ?>

                                            </td>
                                            <td class="text-center">
                                                <button 
                                                    class="btn btn-primary btn-sm btn-icon"  
                                                    data-toggle="modal"
                                                    data-target="#read_message_<?php echo e($value->id); ?>"
                                                >
                                                    <i class=" mdi mdi-email-outline"></i>  
                                                    Read Message
                                                </button>

                                                <form class="d-inline" action="<?php echo e(route('communication.destroy', $value->cusb_id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>  

                                                    <button class="btn btn-danger btn-sm d-inline" type="submit">
                                                        <i class="mdi mdi-delete"></i>
                                                    </button> 
                                                </form>
                                            </td>
                                        </tr> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <th colspan="7">
                                                    <p class="text-muted text-center">
                                                        It's empty here.
                                                    </p>
                                                </th>
                                            </tr> 
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div> 

                    </div>
                </div>
            </div> 
        </div>
    </div> 
    

 


    <?php echo $__env->make("admin/email/communication", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
    <?php echo $__env->make("admin/sms/communication", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
    
    <div  class="right card-body p-0 hidden" id="loading">
        <div class="sub-loading" role="document">
            <div class="loader-demo-box">
                <div class="circle-loader"></div>
            </div>
        </div>
    </div>  



    <?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <script>
        $(document).ready(function() {
            $('#communication > li > a').on('click touchstart', function(e){
                e.preventDefault();

                var data = $(this).attr('rel');
                $('.active').removeClass('active'); 
                $(this).addClass('active');
               
                $('#communication-content > div.d-block').removeClass('d-block');
                $('#'+data).addClass('d-block');

            });
            $('#comm_send_mail').on('click touchstart', function(e){ 
                $('#comm_form').submit();
                $('div#loading').removeClass('hidden');
            });
            $('#comm_send_sms').on('click touchstart', function(e){ 
                $('#comm_form_sms').submit();
                $('div#loading').removeClass('hidden');
            });
            
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/communication.blade.php ENDPATH**/ ?>