 
<?php $__env->startSection('content'); ?>      
    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
    <!-- main content --> 
    <style>
        .notification-active{
            background-color: #e4fbf9 !important;
        }
    </style>
    <div class="main-content">
        <div class="page-header">
            <h3>Notifications</h3>
        </div> 
        <!-- page content -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="notifications"> 
                        <!-- single notification --> 
                        <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 

                            <?php echo $__env->make("admin/modal/notification", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

                            <div class="single-notification notification-identifier<?php echo e($notification->id); ?> <?php if($notification->nstatus == 'active'): ?> notification-active <?php endif; ?>">

                                <div style="display:flex">
                                    <?php if( $notification->type == "message" ): ?>
                                        <div class="notification-icon bg-purple">
                                            <i class=" mdi mdi-message-text-outline"></i>
                                        </div>
                                    <?php elseif( $notification->type == "delete" ): ?>
                                        <div class="notification-icon bg-danger"> 
                                            <i class=" mdi mdi-delete"></i> 
                                        </div>
                                    <?php elseif( $notification->type == "calendar" ): ?>
                                        <div class="notification-icon bg-secondary"> 
                                            <i class=" mdi mdi-calendar"></i> 
                                        </div>
                                    <?php elseif( $notification->type == "newaccount" ): ?>
                                            <?php if($notification->image_name): ?> 
                                                <img 
                                                    src="<?php echo e(url('/images'). '/' .$notification->image_name); ?> " 
                                                    class="img-responsive" 
                                                    style="height: 50px; width: auto;"
                                                >    
                                            <?php else: ?> 
                                                <div class="notification-icon bg-warning"> 
                                                    <i class="mdi mdi-account-plus"></i>  
                                                    
                                                </div>
                                            <?php endif; ?>
                                    <?php elseif( $notification->type == "payment" ): ?>
                                        <div class="notification-icon bg-success"> 
                                            <i class="mdi mdi-credit-card"></i> 
                                        </div>
                                    <?php endif; ?> 
                                        <div class="notification-message  " >
                                            <div class="notification-date"><?php echo e(date('F j, Y h:ia', strtotime($notification->created_at))); ?></div>
                                            <?php echo $notification->message; ?> 
                                        </div> 
                                </div>
                                <div class="" style="display: flex;"> 
                                    <a href="#" class="delete_notification" rel="<?php echo e($notification->id); ?>" 
                                                    data-toggle="modal" 
                                                    data-target="#notificationModal<?php echo e($notification->id); ?>">
                                        <i class="mdi mdi-eye"></i> 
                                    </a> 
                                    <form id="deleteNot<?php echo e($notification->id); ?>" action="<?php echo e(route('notification.destroy', $notification->id)); ?>" method="POST" >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>  
                                        <a href="#" class="trash-notification" rel="deleteNot<?php echo e($notification->id); ?>">
                                            <i class="mdi mdi-delete " style="color: red;"></i> 
                                        </a> 
                                    </form>
                                </div>
                            </div> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                            <?php echo $__env->make("admin/empty/empty", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                        <?php endif; ?> 
                    </div> 
                </div>
            </div>
        </div>
    </div>
</div>  
<?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<script> 



    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
        } 
    });

    $('.delete_notification').on('click touchstart', function(e){
        e.preventDefault();
        
       
        var data = $(this).attr('rel');  
            var url = '<?php echo e(route("notification.update", ":id")); ?>';
                url = url.replace(':id', data);
 
            $.ajax({
                url: url,
                method: 'PUT', 
                data: {
                    _token: '<?php echo e(csrf_token()); ?>' 
                },
                success: function(status){ 
                    if(status == true){
                        $('.notification-identifier'+data).removeClass('notification-active');
                    } 
                }
            }); 




    });

    $('.trash-notification').on('click touchstart', function(e){
        e.preventDefault();
        var data = $(this).attr('rel');
        $('#'+data).submit();
    });
</script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/notifications.blade.php ENDPATH**/ ?>