 
<?php $__env->startSection('content'); ?>     
        <!-- Admin home page --> 
        <!-- sidebar --> 

    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
    <?php echo $__env->make("admin/modal/fleet", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
 
    <!-- main content -->
    <div class="main-content">
        <div class="page-header">
            <button  
                type="button" 
                class="btn btn-primary btn-icon pull-right ml-5" 
                data-toggle="modal" 
                data-target="#create"
                <?php echo e($permission_status); ?>

            >
                <i class=" mdi mdi-plus-circle-outline"></i> 
                Add Vehicle 
            </button>
            <h3>Fleet</h3>
            <p>Vehicles for your branch</p>
        </div> 
        <!-- page content -->
        <div class="row">
            <div class="col-md-12">
                <div class="card"> 
                    <div class="card-body p-0">
                        <div class="table-responsive" style="height: 80vh"> 
                            <?php if(\Session::has('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo \Session::get('success'); ?> 
                                </div>
                            <?php endif; ?>   
                            <?php if(\Session::has('error')): ?>
                                <div class="alert alert-danger">
                                    <?php echo \Session::get('error'); ?> 
                                </div>
                            <?php endif; ?>  
                            <table class="table table-striped mb-0 mw-1000">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Car Type</th>
                                        <th>Car No.</th>
                                        <th>Plate</th>
                                        <th>M. Year</th> 
                                        <th class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($fleet)): ?>

                                        <?php $__currentLoopData = $fleet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($key+1); ?></th>
                                            <td><strong><?php echo e($car->make); ?> <?php echo e($car->model); ?></strong></td>
                                            <td>#<?php echo e($car->car_no); ?></td>
                                            <td><?php echo e($car->car_plate); ?></td>
                                            <td><?php echo e($car->model_year); ?></td> 
                                            <td class="text-center">
                                                <a class="btn btn-primary btn-sm btn-icon" href="<?php echo e(route('fleet.show', $car->id)); ?>" >
                                                    <i class="mdi mdi-calendar-text"></i> 
                                                    Schedule
                                                </a>
                                                <div class="dropdown inline-block">
                                                    <button 
                                                        class="btn btn-default btn-sm btn-icofn dropdown-toggle" 
                                                        data-toggle="dropdown"
                                                        id="menu1"
                                                        aria-haspopup="true" 
                                                        aria-expanded="false"
                                                    >
                                                        <i class="mdi mdi-dots-vertical"></i>
                                                    </button>
                                                    <ul 
                                                        class="dropdown-menu" 
                                                        role="menu" 
                                                        aria-labelledby="menu1"
                                                    >
                                                        <li role="presentation">
                                                            <a   
                                                                href="<?php echo e(route('fleet.form.show', $car->id)); ?>"
                                                             >  
                                                                <i class="mdi mdi-calendar-plus"></i> 
                                                                add schedule
                                                            </a>
                                                        </li>


                                                        <li role="presentation">
                                                            <a  
                                                                data-toggle="modal" 
                                                                data-target="#update<?php echo e($car->id); ?>"
                                                                href="#"
                                                             >  
                                                                <i class="mdi mdi-pencil"></i> 
                                                                Edit
                                                            </a>
                                                        </li>


                                                        <li role="presentation">
                                                            <form id="deleteFleet<?php echo e($car->id); ?>" action="<?php echo e(route('fleet.destroy', $car->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>  
                                                                <a  
                                                                    href="#" 
                                                                    class="fleet_delete"
                                                                    rel="deleteFleet<?php echo e($car->id); ?>"
                                                                >
                                                                    <i class="mdi mdi-delete"></i> 
                                                                    Delete
                                                                </a> 
                                                            </form>
                                                        </li>
                                                    </ul>
                                                </div> 
                                            </td>
                                        </tr>


                                        <?php echo $__env->make("admin/modified/fleet", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr><th colspan="7" class="text-center">It's empty here.</th></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 
    <?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <script>
        
        $('.fleet_delete').on('click touchstart', function(e){ 
            e.preventDefault();
            if(confirm("Are you sure to delete this? This Fleet and all it's data will be deleted")){

                $fleet_data = $(this).attr('rel');
                $('#'+$fleet_data).submit();

            } 
        });


    //Edit Vehicle
    $('.editcar').on('click',function(){
        var data = JSON.parse($(this).attr('data-scope'));
        $('#create .modal-title').text('Edit Branch');
        $('.submitbtn').text('Save changes');
        $('.simcy-form').attr('action',`<?php echo e(url('Fleet@edit')); ?>${data.id}`);
        $('.carno').val(data.carno);
        $('.carplate').val(data.carplate);
        $('.carmake').val(data.carmake);
        $('.carmodel').val(data.carmodel);
        $('.modelyear').val(data.modelyear);
        for(var i =0;i<=data.names.length;i++){
            console.log(data.names[i]);
        }
        $('.instructors').val(data.instructors);
        $('.carimg').attr('data-default-file',`<?php echo e(asset("uploads/fleet/")); ?>${data.carimg}`); 
    });
    //Add Vehicle
    $('.addcar').on('click',function(){
        $('#create .modal-title').text('Add Fleet');
        $('.submitbtn').text('Add Branch');
        $('.simcy-form').attr('action',"<?php echo e(url('Branch@store')); ?>");
        $('.carno').val('');
        $('.carplate').val('');
        $('.carmake').val('');
        $('.carmodel').val('');
        $('.modelyear').val('');
        $('.instructors').val('');
        $('.carimg').attr('data-default-file',' '); 

    });
    //Select instructor
    $('.instructor').on('change', function(){
      var instructors = $('.instructors');
      var insdata = $('.insdata');
      var value = $(this).val();
      if(instructors.val().length < 1){
          instructors.val(value);
          insdata.html('<span class="badge badge-pill badge-primary col-md-5 mt-2 ml-1">'+$('.instructor option:selected').text()+'</span>');
      } else {
          if(instructors.val().indexOf(value) < 0){
            insdata.append('<span class="badge badge-pill badge-primary col-md-5 mt-2 ml-1">'+$('.instructor option:selected').text()+'</span>');
            instructors.val(instructors.val()+','+value);
          } else {
              notify('Oops!','This item already exists.','warning','Ok');
          }
      }
    });
    //On submit
    $('.simcy-form').on('submit',function(){
      $('.instructors').attr('disabled',false);
    });
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/fleet.blade.php ENDPATH**/ ?>