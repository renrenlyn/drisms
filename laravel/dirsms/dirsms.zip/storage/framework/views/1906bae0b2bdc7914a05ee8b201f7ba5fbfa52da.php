 
<?php $__env->startSection('content'); ?>     
        <!-- Admin home page --> 
        <!-- sidebar --> 

    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
    <?php echo $__env->make("admin/modal/school", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

 
  
<!-- main content -->
<div class="main-content">
    <div class="page-header">
        <button type="button" class="btn btn-primary btn-icon pull-right ml-5 " <?php echo e($permission_status); ?> data-toggle="modal" data-target="#create"><i class=" mdi mdi-plus-circle-outline"></i> Add School </button>
        <h3>Schools</h3>
        <p>These are independent schools that signed up. </p>
    </div>
    
    <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
            <?php echo \Session::get('success'); ?> 
        </div>
    <?php endif; ?>   
    <?php if(\Session::has('error')): ?>
        <div class="alert alert-danger">
            <?php echo \Session::get('error'); ?> 
        </div>
    <?php endif; ?> 

    <!-- page content -->
    <div class="row">

        <?php $__empty_1 = true; $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
         
        <?php if($school->status == "Active"): ?>

        <!-- school -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="school">
                            <div class="school-heading">
                                <div class="school-icon"><?php echo e(mb_substr($school->name, 0, 1, 'utf-8')); ?></div>
                                <div class="school-details">
                                    <h5><?php echo e($school->name); ?></h5>
                                    <span><?php echo e($school->email); ?></span>
                                    <span>
                                <?php if( !empty($school->phone) ): ?> <?php echo e($school->phone); ?> <?php else: ?> Phone not set <?php endif; ?>
                                </span>
                                </div>
                            </div>
                            <div class="school-info">
                                <p>
                                    <span><i class="mdi mdi-account-convert"></i></span>
                                    <?php echo e($school->students); ?> Active Students
                                </p>
                                <p>
                                    <span><i class="mdi mdi-account-multiple-outline"></i></span>
                                    <?php echo e($school->instructors); ?> Instructors
                                </p>
                                <p>
                                    <span><i class="mdi mdi-map-marker-multiple"></i></span>
                                    <?php echo e($school->branches); ?> Branches
                                </p>
                                <p>
                                    <span><i class="mdi mdi-map"></i></span>
                                <?php if( !empty($school->address) ): ?> <?php echo e($school->address); ?> <?php else: ?> Address not set <?php endif; ?>
                                </p>
                            </div>
                            <div class="school-footer">
                                <div class="dropdown pull-right">
                                    <span class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="mdi mdi-dots-horizontal"></i> </span>
                                    <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                        
                                        <li role="presentation">
                                            <a role="menuitem"  
                                                href="<?php echo e(route('school.course.review', $school->id)); ?>" 
                                                 
                                                >   
                                                <i class="mdi mdi-eye"></i>
                                                Review Course
                                            </a>
                                        </li>
                                        
                                        <li role="presentation">
                                            <a role="menuitem"  
                                                href="<?php echo e(route('school.course.add', $school->id)); ?>" 
                                                class="<?php echo e($permission_status); ?>"
                                                > 
                                                <i class="mdi mdi-plus-circle-outline"></i>
                                                Add Course
                                            </a>
                                        </li>
                                        <li role="presentation">
                                            <a role="menuitem"
                                                href="#" 
                                                input="schoolid" 
                                                modal="#sendemail<?php echo e($school->id); ?>" 
                                                class="pass-data <?php echo e($permission_status); ?>" 
                                                value="<?php echo e($school->id); ?>"
                                                > 
                                                <i class="mdi mdi-email-outline"></i> 
                                                Send Email
                                            </a>
                                        </li>
                                        <li role="presentation">
                                            <a role="menuitem" 
                                                href="" 
                                                input="schoolid" 
                                                modal="#sendsms<?php echo e($school->id); ?>" 
                                                class="pass-data <?php echo e($permission_status); ?>" 
                                                value="<?php echo e($school->id); ?>"> 
                                                <i class="mdi mdi-message-text-outline"></i> 
                                                Send SMS
                                            </a>
                                        </li>
                                        
                                        <li role="presentation">
                                            <a role="menuitem" 
                                                class="pass-data <?php echo e($permission_status); ?>" 
                                                modal="#update<?php echo e($school->id); ?>"  
                                                href="#" 
                                                > 
                                                <i class="mdi mdi-pencil"></i> 
                                                Edit
                                            </a>
                                        </li>

                                        <li role="presentation">
                                            
                                            <form id="deleteSchool<?php echo e($school->id); ?>" action="<?php echo e(route('school.destroy', $school->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>  
                                                <a  
                                                    href="#"  
                                                    class="school_delete <?php echo e($permission_status); ?> <?php echo e($permission_delete); ?>"
                                                    rel="deleteSchool<?php echo e($school->id); ?>"
                                                >
                                                    <i class="mdi mdi-server-remove"></i> 
                                                    Suspended
                                                </a> 
                                            </form> 
                                        </li>
                                    </ul>
                                </div>
                                <?php if(($school->status) == 'Active'): ?>
                                <span class="badge badge-success">Active School</span>
                                <?php else: ?>
                                <span class="badge badge-danger">Suspended School</span>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>



                <?php echo $__env->make("admin/modified/school", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
                <?php echo $__env->make("admin/email/school", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
                <?php echo $__env->make("admin/sms/school", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

            
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
            <?php echo $__env->make("admin/empty/empty", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
        <?php endif; ?>
    </div>

</div> 

<!-- end add school -->
<!-- update -->
<div class="modal right fade" id="update" role="dialog" tabindex="-1">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button aria-label="Close" class="close" data-dismiss="modal" type="button"><span aria-hidden="true"><i class="mdi mdi-close-circle-outline"></i></span></button>
                <h4 class="modal-title" id="myModalLabel2">Edit School</h4>
            </div>
            <div class="update-holder"></div>
        </div><!-- modal-content -->
    </div><!-- modal-dialog -->
</div>
<!-- end update -->

 
<?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script> 
 

    $('.school_delete').on('click touchstart', function(e){ 
        e.preventDefault();
        if(confirm("Are you sure you want to do this?")){ 
            $school_data = $(this).attr('rel');
            $('#'+$school_data).submit();
        } 
    })  
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/school.blade.php ENDPATH**/ ?>