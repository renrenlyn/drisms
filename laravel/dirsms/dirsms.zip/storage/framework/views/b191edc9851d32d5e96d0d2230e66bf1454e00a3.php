 
<?php $__env->startSection('content'); ?>      
    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     

    <style>

        ul li{
            list-style: none;
        }
        .form-drisms tbody tr td{
            padding-top: 0px !important; 
            padding-bottom: 0px !important
        }
        .form-drisms tbody tr{
            background-color:white !important;
        }
    </style>
<div class="main-content"> 
    <div class="page-header"> 
        <h3>School</h3>
    </div> 


    <!-- students growth -->
    <div class="row"> 

                <?php $__empty_1 = true; $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5><?php echo e($school->name); ?> ( School )</h5> 
                                <small><?php echo e($school->address); ?></small>
                            </div> 

                            <div class="card-body p-0">
                                <div class="row">
                                    <div class="col-md-12 growth-left">
 
                                        <?php $__empty_2 = true; $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>

                                        
                                            <?php if($branch->school_id == $school->id): ?>
                                               

                                                <h5><?php echo e($branch->name); ?> ( Branch )</h5> 
                                                <small><?php echo e($branch->address); ?></small>
                                    
                                                    <table class="table table-striped">
                                                        <thead>
                                                            <tr> 
                                                                <th scope="col">Select</th>
                                                                <th scope="col">Course Name</th>
                                                                <th scope="col">Hourly</th>
                                                                <th scope="col">Day</th> 
                                                                <th scope="col">Date Start</th>
                                                                <th scope="col">Date End</th>
                                                                <th scope="col">Duration</th>
                                                                <th scope="col">Period</th> 
                                                                <th scope="col">Price</th>
                                                                <th scope="col">Status</th>    
                                                            </tr>
                                                        </thead>
                                                        <tbody> 
                                                            <?php $__empty_3 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>

                                                                    <?php $__empty_4 = true; $__currentLoopData = $school_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_4 = false; ?>

                                                                        <?php if($sc->course_id == $course->id): ?>

                                                                            <?php if($sc->school_id == $school->id): ?> 
                                                                                <tr> 
                                                                                    <td><input type="radio" name="ec_form<?php echo e($sc->id); ?>-<?php echo e(Auth::user()->id); ?>-<?php echo e($school->id); ?>-<?php echo e($branch->id); ?>"   class="ec_forn_c" rel="ec_form<?php echo e($sc->id); ?>-<?php echo e(Auth::user()->id); ?>-<?php echo e($school->id); ?>-<?php echo e($branch->id); ?>"> </td> 
                                                                                    <td><?php echo e($course->name); ?></td> 
                                                                                    <td><?php echo e($sc->time_start_end); ?></td>  
                                                                                    <td>
                                                                                        <?php $__empty_5 = true; $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_5 = false; ?>
                                                                                            <?php if($sc->id == $day->sc_id): ?>
                                                                                                <?php echo e($day->day); ?> 
                                                                                            <?php endif; ?>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_5): ?>
                                                                                            No day available yet
                                                                                        <?php endif; ?> 
                                                                                    </td>  
                                                                                    <td><?php echo e(date('l, F d y', strtotime( $sc->start ))); ?></td> 
                                                                                    <td><?php echo e(date('l, F d y', strtotime( $sc->end ))); ?></td> 
                                                                                    <td><?php echo e($sc->duration); ?></td> 
                                                                                    <td><?php echo e($sc->period); ?></td> 
                                                                                    <td><?php echo e($course->price); ?></td> 
                                                                                    <td><?php echo e($course->status); ?></td>  
 
                                                                                </tr>  
                                                                                <tr  class="dc-cls hidden" id="ec_form<?php echo e($sc->id); ?>-<?php echo e(Auth::user()->id); ?>-<?php echo e($school->id); ?>-<?php echo e($branch->id); ?>"> 
                                                                                    <td colspan ="10">



                                                                                            <div class="mb-3">Please Check <?php echo e($sc->id); ?>-<?php echo e(Auth::user()->id); ?>-<?php echo e($school->id); ?>-<?php echo e($branch->id); ?></div> 
                                                                                    


                                                                                    
                                                                                            <form action="<?php echo e(route('enrollment.store' )); ?>" method="POST">
                                                                                                <?php echo csrf_field(); ?> 
                                                                                                    
                                                                                                <input type="hidden" name="school_id" value="<?php echo e($school->id); ?>" />
                                                                                                <input type="hidden" name="branch_id" value="<?php echo e($branch->id); ?>" />
                                                                                                <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>" />
                                                                                                
                                                                                                <div class="form-group">
                                                                                                    <div class="row">
                                                                                                        <div class="col-md-4"> 
                                                                                                            <table class="table table-borderless form-drisms">
                                                                                                                <tbody>
                                                                                                                    <tr>
                                                                                                                        <td class=""><input type="checkbox" name="driving_lto_requirement" value="Driving for LTO requirement"/></td>
                                                                                                                        <td> <label>Driving for LTO requirement</label></td>
                                                                                                                    </tr> 
                                                                                                                    <tr>
                                                                                                                        <td><input type="checkbox" name="theoretical_driving_course" value="15 Hours Theoretical Driving Course"/></td>
                                                                                                                        <td><label>15 Hours Theoretical Driving Course</label> </td>
                                                                                                                    </tr> 
                                                                                                                    <tr>
                                                                                                                        <td><input type="checkbox" name="practical_driving_course_mv" value="8 Hours Practical Driving Course (MV)"/></td>
                                                                                                                        <td><label>8 Hours Practical Driving Course (MV)</label> </td>
                                                                                                                    </tr> 
                                                                                                                    <tr> 
                                                                                                                        <td><input type="checkbox" name="manual_transmission_mv" value="Manual Transmission"/></td>
                                                                                                                        <td>  <label>Manual Transmission</label> </td>
                                                                                                                    </tr> 
                                                                                                                    <tr>
                                                                                                                        <td><input type="checkbox" name="automatic_transmission_mv" value="Automatic Transmission"/></td>
                                                                                                                        <td><label>Automatic Transmission</label></td>
                                                                                                                    </tr>
                                                                                                                </tbody>
                                                                                                            </table>  
                                                                                                        </div>

                                                                                                        <div class="col-md-4"> 
                                                                                                            <table class="table table-borderless form-drisms">
                                                                                                                <tbody> 
                                                                                                                    <tr>
                                                                                                                        <td><input type="checkbox" name="practical_driving_course_mc" value="8 Hours Practical Driving Course (MC)" /></td>
                                                                                                                        <td><label>8 Hours Practical Driving Course (MC)</label> </td>
                                                                                                                    </tr>  
                                                                                                                    <tr> 
                                                                                                                        <td><input type="checkbox" name="manual_transmission_mc" value="Manual Transmission" /></td>
                                                                                                                        <td>  <label>Manual Transmission</label> </td>
                                                                                                                    </tr> 
                                                                                                                    <tr>
                                                                                                                        <td><input type="checkbox" name="automatic_transmission_mc" value="Automatic Transmission"/></td>
                                                                                                                        <td><label>Automatic Transmission</label></td>
                                                                                                                    </tr>
                                                                                                                    
                                                                                                                    <tr >
                                                                                                                        <td><input type="checkbox" class="others_mc" /></td>
                                                                                                                        <td><label>OTHERS</label></td>
                                                                                                                    </tr>
                                                                                                                    <tr>
                                                                                                                        <td colspan="2" class="hidden other-transmission">
                                                                                                                            <label>
                                                                                                                                <input type="text" name="others_mc"/>
                                                                                                                            </label>
                                                                                                                        </td> 
                                                                                                                    </tr>
                                                                                                                </tbody>
                                                                                                            </table>  
                                                                                                        </div>
 
                                                                                                        <div class="col-md-4">
                                                                                               
                                                                                                            <label>Where did you know <?php echo e($school->name); ?> ( School )</label>

                                                                                                            <div class="row">
                                                                                                                
                                                                                                                <div class="col-md-6"> 
                                                                                                                    <table class="table table-borderless form-drisms">
                                                                                                                        <tbody> 
                                                                                                                            <tr>
                                                                                                                                <td><input type="checkbox" name="where_did_you_know_school_[]" value="Facebook" /></td>
                                                                                                                                <td><label>Facebook</label> </td>
                                                                                                                            </tr>
                                                                                                                            
                                                                                                                            <tr> 
                                                                                                                                <td><input type="checkbox" name="where_did_you_know_school_[]" value="Radio" /></td>
                                                                                                                                <td>  <label>Radio</label> </td>
                                                                                                                            </tr>

                                                                                                                            
                                                                                                                            <tr>
                                                                                                                                <td><input type="checkbox" name="where_did_you_know_school_[]" value="Google" /></td>
                                                                                                                                <td><label>Google</label></td>
                                                                                                                            </tr>
                                                                                                                            
                                                                                                                            <tr>
                                                                                                                                <td><input type="checkbox" name="where_did_you_know_school_[]" value="Refferal" /></td>
                                                                                                                                <td><label>Refferal</label></td>
                                                                                                                            </tr>
                                                                                                                            
                                                                                                                        </tbody>
                                                                                                                    </table>  
                                                                                                                </div>
                                                                                                                <div class="col-md-6"> 
                                                                                                                    <table class="table table-borderless form-drisms">
                                                                                                                        <tbody> 
                                                                                                                            <tr>
                                                                                                                                <td><input type="checkbox" name="where_did_you_know_school_[]" value="TV" /></td>
                                                                                                                                <td><label>TV</label> </td>
                                                                                                                            </tr> 
                                                                                                                            <tr> 
                                                                                                                                <td><input type="checkbox" name="where_did_you_know_school_[]" value="Flyers"/></td>
                                                                                                                                <td>  <label>Flyers</label> </td>
                                                                                                                            </tr> 
                                                                                                                            <tr>
                                                                                                                                <td><input type="checkbox" name="where_did_you_know_school_[]" value="Billboard"/></td>
                                                                                                                                <td><label>Billboard</label></td>
                                                                                                                            </tr> 
                                                                                                                            <tr>
                                                                                                                                <td><input type="checkbox" class="others_"/></td>
                                                                                                                                <td><label>Others</label></td>
                                                                                                                            </tr> 
                                                                                                                        </tbody>
                                                                                                                    </table>   
                                                                                                                </div> 
                                                                                                                <div class="hidden other_inform">

                                                                                                                        <label> Refered by: </label> 
                                                                                                                    <input type="text" name="where_did_you_know_school_[]"> 

                                                                                                                </div>
                                                                                                            </div> 
                                                                                                        </div>

                                                                                                    </div> 
                                                                                                </div>
 

                                                                                                <div class="form-group">
                                                                                                    <label>Additional information about you</label>
                                                                                                    <div class="row">
                                                                                                    

                                                                                                        <div class="col-md-6"> 
                                                                                                            <table class="table table-borderless form-drisms">
                                                                                                                <tbody>
                                                                                                                   
                                                                                                                    <tr>
                                                                                                                        <td><label>Civil Status</label> </td>
                                                                                                                        <td><input type="text" name="civil_status" /></td>
                                                                                                                    </tr> 
                                                                                                                    <tr> 
                                                                                                                        <td>  <label>Place of Birth</label> </td>
                                                                                                                        <td><input type="text" name="pob" /></td>
                                                                                                                    </tr> 
                                                                                                                    <tr> 
                                                                                                                        <td><label>Height</label></td>
                                                                                                                        <td><input type="text" name="height" /></td>
                                                                                                                    </tr>
                                                                                                                    
                                                                                                                    <tr> 
                                                                                                                        <td><label>Weigth</label></td>
                                                                                                                        <td><input type="text" name="weigth"/></td>
                                                                                                                    </tr>
                                                                                                                    
                                                                                                                    <tr> 
                                                                                                                        <td><label>Blood Type</label></td>
                                                                                                                        <td><input type="text" name="blood_type"/></td>
                                                                                                                    </tr>
                                                                                                                </tbody>
                                                                                                            </table>  
                                                                                                        </div> 


                                                                                                        <div class="col-md-6"> 
                                                                                                            <table class="table table-borderless form-drisms">
                                                                                                                <tbody> 
                                                                                                                    <tr>
                                                                                                                         <td> <label>Name of Mother</label></td>  
                                                                                                                         <td class=""><input type="text" name="name_of_mother"/></td>
                                                                                                                     
                                                                                                                    </tr> 
                                                                                                                    <tr>
                                                                                                                        <td><label>Name of Father</label> </td>
                                                                                                                        <td><input type="text" name="name_of_father"/></td>
                                                                                                                    </tr> 
                                                                                                                    <tr>      
                                                                                                                        <td> <label>Person to Notify in Case of Emergency:</label></td> 
                                                                                                                        <td class=""><input type="text" name="person_notify_in_case_of_emergency"/></td>
                                                                                                                    </tr> 
                                                                                                                    <tr>
                                                                                                                        <td><label>Address</label> </td>
                                                                                                                        <td><input type="text" name="guardian_address"/></td>
                                                                                                                    </tr> 
                                                                                                                    <tr>
                                                                                                                        <td><label>Contact Number</label> </td>
                                                                                                                        <td><input type="text" name="guardian_number"/></td>
                                                                                                                    </tr> 
                                                                                                                    <tr> 
                                                                                                                        <td>  <label>Place of Birth</label> </td>
                                                                                                                        <td><input type="text" name="guardian_pob"/></td>
                                                                                                                    </tr> 
                                                                                                                    <tr>
                                                                                                                        <td><label>Relation</label></td>
                                                                                                                        <td><input type="text" name="guardian_relation"/></td>
                                                                                                                    </tr>
                                                                                                                     
                                                                                                                </tbody>
                                                                                                            </table>  
                                                                                                        </div> 
                                                                                                    </div>
                                                                                                </div>
 


                                                                                                <div class="form-group">
                                                                                                    <div class="row"> 
                                                                                                        <div class="col-md-6"> 
                                                                                                            <label>Years of Experience</label>
                                                                                                            <select class="form-control" name="y_e" required="">  
                                                                                                                <option value="more than a months" selected>more than a months</option>   
                                                                                                                <option value="1 year">1 year</option>   
                                                                                                                <option value="2 years">2 years</option>   
                                                                                                                <option value="more than 5 years">more than 5 years</option>    
                                                                                                            </select>  
                                                                                                        </div>
                                                                                                        <div class="col-md-6"> 


                                                                                                        <label>TO BE ACCOMPLISHED BY PERSONEL</label>

                                                                                                            <table class="table table-borderless form-drisms">
                                                                                                                <tbody>
                                                                                                                    <tr>      
                                                                                                                        <td><label>O.R.No.</label></td> 
                                                                                                                        <td class=""><input type="text" name=""/></td>
                                                                                                                    </tr> 
                                                                                                                    <tr>
                                                                                                                        <td><label>Amount Paid</label> </td>
                                                                                                                        <td><input type="text" name=""/></td>
                                                                                                                    </tr>  
                                                                                                                     
                                                                                                                </tbody>
                                                                                                            </table>  
                                                                                                        </div> 

                                                                                                    </div> 
                                                                                                </div> 




                                                                                                <div class="form-group">
                                                                                                    <div class="row">  
                                                                                                        <div class="col-md-12"> 

 

                                                                                                            <table class="table table-borderless form-drisms">
                                                                                                                <tbody>
                                                                                                                    <tr>      
                                                                                                                        <td> <label>Signature:</label></td> 
                                                                                                                        <td><label>Assisted by: </label> </td>
                                                                                                                    </tr> 
                                                                                                                    <tr>
                                                                                                                          <td class=""><hr></td> 
                                                                                                                          <td class=""><hr></td>
                                                                                                                    </tr>   
                                                                                                                </tbody>
                                                                                                            </table>  

                                                                                                            <div class="alert alert-danger">NOTE: REGISTRATION FEE OF P2000 IS NON-REFUNDABLE</div>
                                                                                                        </div> 

                                                                                                    </div> 
                                                                                                </div> 
                                                                             
                                                                                                <div class="form-group">
                                                                                                    <div class="row">
                                                                                                        <div class="col-md-12"> 
                                                                                                            <input type="submit" value="Register"  class="btn btn-primary"  <?php if(Auth::user()->enrollment_status == 1): ?>  disabled <?php endif; ?>/>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>


                                                                                            </form> 
                                                                                    </td>
                                                                                </tr>





                                                                            <?php endif; ?> 
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_4): ?>
                                                                    
                                                                    <?php endif; ?> 
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
                                                            
                                                            <?php endif; ?>
                                                        </tbody>
                                                    </table> 

                                            <?php endif; ?> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?> 
                                        <?php endif; ?> 
                                               
                                    </div>
                                    <div class="col-md-6">
                                        <div class="student-growth-chart mt-15"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?> 
    </div> 
</div>


<?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

<script>
    $('.ec_forn_c').on('change', function(){
     
            $('.ec_forn_c').not(this).prop('checked',false);

            $data = $(this).attr('rel');
            
            $('.dc-cls').addClass('hidden'); 
            $('#'+$data).removeClass('hidden'); 
         
    });

    $('.others_mc').on('change', function(){

        if($(this).is(":checked")){ 
            $('.other-transmission').removeClass('hidden');
        }else{

            $('.other-transmission').addClass('hidden');
        }
    })

    $('.others_').on('change', function(){

        if($(this).is(":checked")){ 
            $('.other_inform').removeClass('hidden');
        }else{

            $('.other_inform').addClass('hidden');
        }
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/student/schedule.blade.php ENDPATH**/ ?>