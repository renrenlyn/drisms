 
<?php $__env->startSection('content'); ?>      
    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     

<div class="main-content">
    <div class="page-header">
        <a href="<?php echo e(url('admin/student')); ?>" class="btn btn-default btn-icon pull-right">
            <i class="mdi mdi-backup-restore"></i> 
            Student Page 
        </a>
        <h3></h3>
    </div> 
  
        <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                                <h5> <?php echo e(ucfirst($user->fname)); ?> <?php echo e(ucfirst($user->lname)); ?> </h5>
                        </div> 
                        <div class="card-body p-0">
                            <div class="row">
                                <div class="col-md-12 growth-left"> 
   
                                        <?php if($student_courses): ?>
                                            <table class="table table-striped">
                                                <thead>
                                                    <tr> 
                                                        <th scope="col">School</th>
                                                        <th scope="col">Branch</th>
                                                        <th scope="col">Course</th>
                                                        <th scope="col">Classes</th>
                                                        <th scope="col">Price</th>
                                                        <th scope="col">Day</th>
                                                        <th scope="col">Time</th>
                                                        <th scope="col">Start</th>
                                                        <th scope="col">End</th>
                                                        <th scope="col">Duration</th>
                                                        <th scope="col">Period</th>  
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <?php $__currentLoopData = $student_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                        <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                            <?php if($val->school_id == $school->id): ?> 
                                                                <?php $__currentLoopData = $school_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                    <?php if($sc->id == $val->school_course_id): ?>  
                                                                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                            <?php if($sc->course_id == $course->id): ?>  
                                                                                <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                                    <?php if($sc->id == $day->sc_id): ?>  
                                                                                        <?php if($user->id == $val->student_id): ?>  
                                                                                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                                                                                <tr>
                                                                                                    <th scope="row"><?php echo e($school->name); ?></th>
                                                                                                    <td>  
                                                                                                        <?php if($branches): ?> 
                                                                                                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                                                                <?php if($val->branch_id == $branch->id): ?>
                                                                                                                    <?php echo e($branch->name); ?>  
                                                                                                                <?php endif; ?>

                                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                                                                                        <?php else: ?>
                                                                                                            No branch specify
                                                                                                        <?php endif; ?> 
                                                                                                    </td> 
                                                                                                    <td><?php echo e($course->name); ?></td> 
                                                                                                    <td><?php echo e($class->type); ?></td> 
                                                                                                    <td><?php echo e($course->price); ?></td> 
                                                                                                    <td><?php echo e($day->day); ?></td> 
                                                                                                    <td><?php echo e($sc->time_start_end); ?></td> 
                                                                                                    <td><?php echo e($sc->end); ?></td> 
                                                                                                    <td><?php echo e($sc->start); ?></td> 
                                                                                                    <td><?php echo e($sc->duration); ?></td> 
                                                                                                    <td><?php echo e($sc->period); ?></td>  

 
                                                                                                </tr>


                                                                                                
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                                                                         <?php endif; ?>
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
 
                                        <?php else: ?>
                                            <?php echo $__env->make("admin/empty/empty", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>         
                                        <?php endif; ?> 
                                </div>
                                <div class="col-md-6">
                                    <div class="student-growth-chart mt-15"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div> 
    </div> 

    <?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/student_schedule.blade.php ENDPATH**/ ?>