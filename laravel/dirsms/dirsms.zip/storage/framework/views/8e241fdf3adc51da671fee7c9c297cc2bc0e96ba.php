 
<?php $__env->startSection('content'); ?>     
        <!-- Admin home page --> 
        <!-- sidebar -->  
    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

    

    <style>

        footer{
            margin: 0 !important;
        }
    </style>
<div class="main-content">
    <div class="page-header">
        <h3><?php echo e($user->fname); ?> <?php echo e($user->lname); ?></h3>
    </div> 
    <!-- page content -->
    <div class="row"> 
        <div class="p-0">

                        <div class="slimscroll-profile-menu"> 

                            <div class="user-profile-pic"> 
                                <?php if(!empty($user->image_name)): ?>
                                    <img 
                                        src="<?php echo e(url('/images'). '/' .$user->image_name); ?> " 
                                        class="img-responsive" 
                                    >   
                                <?php else: ?>
                                    <img 
                                        src="<?php echo e(url('/assets/images/avatar.png')); ?> " 
                                        class="img-responsive" 
                                    > 
                                <?php endif; ?> 


                            </div>
                            <div class="user-profile-info">
                                <h5><?php echo e($user->fname); ?> <?php echo e($user->lname); ?></h5> 
                            </div> 
                            <div class="profile-more-section">
                                <ul class="nav nav-tabs">
                                <li><a data-toggle="tab" href="#account" class="active">Account Info</a></li>
                                <!-- <li><a data-toggle="tab" href="#activity">Activity</a></li> -->
                                </ul>

                                <div class="tab-content">
                                    <div id="account" class="tab-pane fade in show active">
                                        <table>
                                            <tr>
                                                <td class="profile-item-title">Email</td>
                                                <td class="profile-item-value"><?php echo e($user->email); ?></td>
                                            </tr>
                                            <tr>
                                                <td class="profile-item-title">Phone</td>
                                                <td class="profile-item-value"><?php echo e($user->phone); ?></td>
                                            </tr>
                                            <tr>
                                                <td class="profile-item-title">Date of Birth</td>
                                                <td class="profile-item-value">
                                                <?php if( $user->dob != '0000-00-00' ): ?> 
                                                <span><?php echo e(date('F j, Y', strtotime($user->dob))); ?></span>
                                                <?php else: ?>
                                                <span class="text-muted">Not set</span>
                                                <?php endif; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="profile-item-title">Gender</td>
                                                <td class="profile-item-value"><?php echo e($user->gender); ?></td>
                                            </tr>
                                            <tr>
                                                <td class="profile-item-title">Address</td>
                                                <td class="profile-item-value"><?php echo e($user->address); ?></td>
                                            </tr>
                                        </table>
                                    </div>
                                   
                                        <!-- <div id="activity" class="tab-pane fade">
                                            <ol class="activity-feed">
                                            <?php if(!empty($timeline)): ?>
                                                <?php $__currentLoopData = $timeline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="feed-item">
                                                    <time class="date" datetime="9-25"><?php echo e(date('d F, Y',strtotime($activity->created_at))); ?></time>
                                                    <?php echo e($activity->activity); ?>

                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <li class="feed-item">
                                                    <span class="text">No activities found.</span>
                                                </li>
                                            <?php endif; ?>
                                            </ol>
                                        </div> -->
                                </div>
                            </div>
        </div> 
    </div> 
</div>


    <?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/profile.blade.php ENDPATH**/ ?>