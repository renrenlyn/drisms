 
<?php $__env->startSection('content'); ?>     
        <!-- Admin home page --> 
        <!-- sidebar -->  
    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
<!-- main content -->


<div class="main-content">
    <div class="page-header">
 
        <h1>Schedule for <?php echo e($user->role); ?> <?php echo e(ucfirst($user->fname)); ?> <?php echo e(ucfirst($user->lname)); ?></h1>
   
    </div>
 

    <!-- page content -->
    <div class="row">
        <h3>School Schedule</h3>
 
 
        <?php if(!empty($school_course_instructors)): ?>  

            <table class="table table-borderless form-drisms">
                <thead>
                    <th>#</th>
                    <th>School</th>
                    <th>Branch</th>
                    <th>Course</th>
                    <th>Price</th>
                    <th>Days</th>
                    <th>Time Start & End</th>
                    <th>Start</th>
                    <th>End</th>
                    <th>Duration</th>
                    <th>Period</th>
                </thead>
                <tbody> 
                    <?php $__currentLoopData = $school_course_instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr> 
                            <td><?php echo e($key+1); ?></td>  
                            <td><?php echo e($val->s_name); ?></td>  
                            <td><?php echo e($val->b_name); ?></td>  
                            <td><?php echo e($val->c_name); ?></td>  
                            <td> <?php echo e($val->price); ?></td>  
                            <td> <?php echo e($val->days); ?> </td>  
                            <td> <?php echo e($val->time_start_end); ?> </td>  
                            <td> <?php echo e($val->start); ?> </td>  
                            <td> <?php echo e($val->end); ?> </td>  
                            <td> <?php echo e($val->duration); ?> </td>  
                            <td> <?php echo e($val->period); ?> </td>  
                        </tr>   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tbody>
            </table>  
        <?php else: ?> 
            <?php echo $__env->make("admin/empty/empty", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
        <?php endif; ?> 
    </div>





    <!-- page content -->
    <div class="row">
        <h3>Fleet Schedule</h3>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Make</th>
                    <th scope="col">Car Number</th>
                    <th scope="col">Car Plate</th>
                    <th scope="col">Model</th>
                    <th scope="col">Model Year</th>
                    <th scope="col">Time start and Time end</th>
                    <th scope="col">Date Start</th>
                    <th scope="col">Date End</th>
                    <th scope="col">Day</th> 
                    <th scope="col">Duration</th> 
                    <th scope="col">Period</th>  
                    <th scope="col">Action</th>  
                </tr>
            </thead>
            <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $fleets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>
                        <th scope="row"><?php echo e($key + 1); ?></th>
                        <td><?php echo e($val->make); ?></td> 
                        <td><?php echo e($val->car_no); ?></td> 
                        <td><?php echo e($val->car_plate); ?></td> 
                        <td>
                            <?php echo e($val->model); ?>  
                        </td> 
                        <td><?php echo e($val->model_year); ?></td> 
                        <td><?php echo e($val->time_start_end); ?></td> 
                        <td><?php echo e($val->start); ?></td> 
                        <td><?php echo e($val->end); ?></td> 
                        <td><?php echo e($val->day); ?></td>  
                        <td><?php echo e($val->duration); ?></td>  
                        <td><?php echo e($val->period); ?></td>    
                        <td>  

                            <a   
                                href="<?php echo e(route('fleet.form.edit', $val->id)); ?>"
                                class="btn btn-primary"
                            >  
                                <i class="mdi mdi-pencil"></i>  
                            </a>
  
                            <form id="deleteFleetSchedule<?php echo e($val->id); ?>" action="<?php echo e(route('fleet.form.delete', $val->id)); ?> " method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>  
                                <a  
                                    href="#"  
                                    class="btn btn-danger fs_delete " 
                                    rel="deleteFleetSchedule<?php echo e($val->id); ?>"
                                >
                                    <i class="mdi mdi-delete"></i>  
                                </a> 
                            </form>  

                        </td>  
                    </tr> 
 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                    <?php echo $__env->make("admin/empty/empty", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
                <?php endif; ?>
            </tbody>
        </table> 
    </div>
















</div>  

<?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 
<script>  
    $('.fs_delete').on('click touchstart', function(e){ 
        e.preventDefault();
        if(confirm("Are you sure to delete this Fleet schedule?")){ 
            $fleet_delete = $(this).attr('rel');
            $('#'+$fleet_delete).submit();
        } 
    })  
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/review/reviewInstructorSchedule.blade.php ENDPATH**/ ?>