 
<?php $__env->startSection('content'); ?>     
        <!-- Admin home page --> 
        <!-- sidebar --> 
   
 
  <style>
    @media  print
    {
        #non-printable { display: none; }
        #printable { 
			display: block; 
			
		}
		.print-body{
			color:#000;
		}
		.text-right{
			color:#000;
		}
		.table-responsive{
			color:#000;
		}
		#print-payment{
			display: none;
		}
		footer{
			display: none;
    	}
    }
    footer{
        margin: 0;
    }
    .text-right {
        display: block;
    }
    h1{
        text-align: center;
    }
    h5{
        text-align: center;
    }
	
  </style>


<div class="print-body">
    


    <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

     <h1>DriSMS</h1>
    <h5>Cagayan de Oro City</h5>
    <h5>============================</h5>

    <div class="container bootstrap snippets bootdey">
	<div class="panel panel-default">
		<div class="panel-body">
			<div class="row">
				<div class="col-md-6 col-sm-6 text-left">
					<h4><strong>Student</strong> Details</h4>
					<ul class="list-unstyled">
						<li><strong>First Name:</strong><?php echo e($invoice->fname); ?></li>
						<li><strong>Last Name:</strong> <?php echo e($invoice->lname); ?></li>
						<li><strong>Gmail:</strong>  <?php echo e($invoice-> email); ?> </li>
					</ul>
				</div>

				<div class="col-md-6 col-sm-6 text-right">
					<h4><strong>Payment</strong> Details</h4>
					<ul class="list-unstyled">
						<li><strong>Account Number:</strong> <?php echo e($invoice->id); ?></li>
						<li><strong>Account Username:</strong> <?php echo e($invoice->username); ?></li>
						
					</ul>

				</div>

			</div>

			<div class="table-responsive">
				<table class="table table-condensed nomargin">
					<thead>
						<tr>
							<th>Course Name</th>
							<th>Student Name</th>
							<th>Date</th>
							<th>Updated</th>
							<th>Total Price</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>
								<div><strong><?php echo e($invoice->name); ?></strong></div>
							</td>
							<td><?php echo e($invoice->fname); ?> <?php echo e($invoice->lname); ?></td>
							<td><?php echo e($invoice->created_at); ?></td>
							<td><?php echo e($invoice->updated_at); ?></td>
							<td><?php echo e($invoice->price); ?></td>
						</tr>
						
					</tbody>
				</table>
			</div>

			<hr class="nomargin-top">
			<div class="row">
				<div class="col-sm-6 text-left">
					<h4><strong>Contact Details </strong> </h4>
					<p class="nomargin nopadding">
						<strong></strong> 
						
					</p><br><!-- no P margin for printing - use <br> instead -->

					<address>
						
						Lapasan, Cagayan de Oro City<br>
						Phone: +63 9682095315 <br>
						Fax: 1-800-565-2390 <br>
						Email:admin@gmail.com
					</address>
				</div>

				<div class="col-sm-6 text-right">
                   
					<ul class="list-unstyled">
						<li><strong>Sub - Total Amount:</strong> <?php echo e($invoice->amount); ?></li>
						<li><strong>Grand Total:</strong> <?php echo e($invoice->price); ?></li>
                        <li>Balance: </li>
					</ul>     
					
				</div>
			</div>
		</div>
	</div>

	
</div>
<div class="text-right">
        <button class="btn btn-primary" id="print-payment"> Print</button>
</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

    <?php endif; ?>

</div>

<?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <script>
        $(document).ready(function() {
 


            $('#print-payment').on('click touchstart', function(e){
                e.preventDefault(); 
                window.print();
            });


            // $('#data-table').DataTable({
            //     dom: 'Bfrtip',
            //     buttons: [
            //         'copyHtml5',
            //         'excelHtml5',
            //         'csvHtml5'
            //     ]
            // });
        });
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/print/payment.blade.php ENDPATH**/ ?>