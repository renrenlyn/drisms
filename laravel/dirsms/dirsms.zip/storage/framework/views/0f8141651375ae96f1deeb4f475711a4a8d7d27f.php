<div class="col-md-12">
    <div class="empty">
        <i class="mdi mdi-alert-circle-outline"></i>
        <h3>It's empty here!</h3>
    </div>
</div><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/empty/empty.blade.php ENDPATH**/ ?>