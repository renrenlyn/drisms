
<!-- modals -->
<div class="modal right fade" id="create<?php echo e($user->id); ?>" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="mdi mdi-close-circle-outline"></i></span></button>
                    <h4 class="modal-title">Update Instructor <?php echo e($user->fname); ?></h4>
                </div>

                <div class="modal-body">
                    <form action="<?php echo e(route('instructor.update', $user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                      <div class="form-group">
                        <div class="row">
                          <div class="col-md-12">
                            <label for="email">Status</label>
 
                            <select class="form-control" name="status" required>
                                
                                <option value="Active" <?php if($user->status == "Active"): ?> selected <?php endif; ?> >Active</option>
                                <option value="Suspended" <?php if($user->status == "Suspended"): ?> selected <?php endif; ?> >Suspended</option>
                                <option value="Inactive" <?php if($user->status == "Inactive"): ?> selected <?php endif; ?> >Inactive</option>
                                
                            </select>


                          </div>
                        </div>
                      </div>

                      <div class="form-group">
                        <div class="row">
                          <div class="col-md-12">
                            <button class="btn btn-primary btn-block">Update Instructor</button>
                          </div>
                        </div>
                      </div> 
                    </form>
                </div>

            </div><!-- modal-content -->
        </div><!-- modal-dialog -->
    </div><!-- modal -->

<?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/modal/instructor.blade.php ENDPATH**/ ?>