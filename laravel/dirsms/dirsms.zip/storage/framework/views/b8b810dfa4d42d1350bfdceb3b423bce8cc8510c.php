 
<?php $__env->startSection('content'); ?>      
    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

    <style>
        ul li{
            list-style: none;
        }
        .form-drisms tbody tr td{
            /* padding-top: 0px !important; 
            padding-bottom: 0px !important */
        }
        .form-drisms tbody tr{
            background-color:white !important;
        } 

        @media  print
        {
            .page-header { display: none; }
            #student-enrollment-record { display: none; }
        } 
    </style> 
    
<!-- main content -->
<div class="main-content"> 
        <div class="page-header"> 
            <h3></h3>
        </div> 
  
        <?php if(Auth::user()->enrollment_status == 1): ?>   
            <div class="row"> 
                <!-- students theoretical page -->
                <div class="row"> 
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3><?php echo e(Auth::user()->fname); ?> <?php echo e(Auth::user()->lname); ?></h3>
                                </div> 
                                <div class="card-body p-0">
                                    <div class="row">
                                        
                                        <div class="col-md-12 growth-left">

                                <?php if($studentcourses): ?>
                                    <?php $__currentLoopData = $studentcourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <div cladd="item-center">
                                                <label>
                                                    <h2>  
                                                        <?php echo e($val->s_name); ?>  
                                                    </h2>
                                                    <small> <?php echo e($val->s_address); ?>  </small>
                                                </label>
                                                <p><?php echo e($val->b_name); ?>   <small> <?php echo e($val->b_address); ?>  </small> </p>
                                            </div>
                                            <div class="row">  
                                                <div class="col-md-12">
                                                    <table class="table table-borderless form-drisms">
                                                        <thead>
                                                            <th>Course</th>
                                                            <th>Price</th>
                                                            <th>Days</th>
                                                            <th>Time Start & End</th>
                                                            <th>Start</th>
                                                            <th>End</th>
                                                            <th>Duration</th>
                                                            <th>Period</th>
                                                        </thead>
                                                        <tbody> 
                                                            <tr> 
                                                                <td> <?php echo e($val->c_name); ?> </td> 
                                                                <td> <?php echo e($val->c_price); ?> </td> 
                                                                <td> <?php echo e($val->day); ?> </td> 
                                                                <td> <?php echo e($val->time_start_end); ?> </td> 
                                                                <td> <?php echo e($val->start); ?> </td> 
                                                                <td> <?php echo e($val->end); ?> </td> 
                                                                <td> <?php echo e($val->duration); ?> </td> 
                                                                <td> <?php echo e($val->period); ?> </td>
                                                            </tr>  
                                                        </tbody>
                                                    </table>  
                                                </div> 
                                                <hr />
                                                <div class="col-md-4"> 
                                                    <table class="table table-borderless form-drisms">
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <?php echo e($val->driving_lto_requirement); ?>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td><?php echo e($val->theoretical_driving_course); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td><?php echo e($val->practical_driving_course_mv); ?> </td>
                                                            </tr>
                                                            <tr>
                                                                <td><?php echo e($val->manual_transmission_mv); ?> </td>
                                                            </tr> 
                                                            <tr>
                                                                <td><?php echo e($val->automatic_transmission_mv); ?></td>
                                                            </tr> 
                                                        </tbody>
                                                    </table>  
                                                </div>
                                                <div class="col-md-4"> 
                                                    <table class="table table-borderless form-drisms">
                                                        <tbody>
                                                            <tr>
                                                                <td><?php echo e($val->practical_driving_course_mc); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td><?php echo e($val->manual_transmission_mc); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td> <?php echo e($val->automatic_transmission_mc); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>OTHERS: <?php echo e($val->others_mc); ?></td>
                                                            </tr> 
                                                        </tbody>
                                                    </table> 
                                                </div>
                                                <div class="col-md-4"> 
                                                    <div cladd="item-center">
                                                        <p> Where did you know <?php echo e($val->s_name); ?> : </p> 
                                                    </div> 
                                                    <table class="table table-borderless form-drisms">
                                                        <tbody>
                                                            <tr>
                                                                <td> <?php echo e($val->where_did_you_know_school_); ?> </td>
                                                            </tr> 
                                                        </tbody>
                                                    </table>  
                                                </div> 
                                            </div>  
                                            <div class="row"> 
                                                <div class="col-md-8">
                                                    <h5>Additional information about you</h5> 
                                                    <div class="row">
                                                        <div class="col-md-6"> 
                                                            <table class="table form-drisms">
                                                                <tbody>
                                                                    <tr>
                                                                        <th>Civil Status: </th>
                                                                        <td><?php echo e($val->civil_status); ?>  </td>
                                                                    </tr>  
                                                                    <tr>
                                                                        <th>Place of Birth: </th>
                                                                        <td><?php echo e($val->pob); ?></td>
                                                                    </tr> 
                                                                    <tr>
                                                                        <th>Height: </th>
                                                                        <td> <?php echo e($val->height); ?> </td>
                                                                    </tr> 
                                                                    <tr>
                                                                        <th>Weigth: </th>
                                                                        <td> <?php echo e($val->weigth); ?>  </td>
                                                                    </tr> 
                                                                    <tr>
                                                                        <th>Blood Type: </th>
                                                                        <td><?php echo e($val->blood_type); ?>  </td>
                                                                    </tr> 
                                                                </tbody>
                                                            </table>  
                                                        </div> 
                                                        <div class="col-md-6"> 
                                                            <table class="table form-drisms">
                                                                <tbody>
                                                                    <tr>
                                                                        <th>Name of Mother: </th>
                                                                        <td> <?php echo e($val->name_of_mother); ?>  </td>
                                                                    </tr>  
                                                                    <tr>
                                                                        <th>Name of Father: </th>
                                                                        <td> <?php echo e($val->name_of_father); ?> </td>
                                                                    </tr> 
                                                                    <tr>
                                                                        <th>Person to Notify in Case of Emergency:  </th>
                                                                        <td> <?php echo e($val->person_notify_in_case_of_emergency); ?> </td>
                                                                    </tr> 
                                                                    <tr>
                                                                        <th>Address: </th>
                                                                        <td> <?php echo e($val->guardian_address); ?> </td>
                                                                    </tr> 
                                                                    <tr>
                                                                        <th>Contact Number: </th>
                                                                        <td> <?php echo e($val->guardian_number); ?>  </td>
                                                                    </tr>  
                                                                    <tr>
                                                                        <th> Place of Birth: </th>
                                                                        <td><?php echo e($val->guardian_pob); ?></td>
                                                                    </tr> 
                                                                    <tr>
                                                                        <th> Relation: </th>
                                                                        <td> <?php echo e($val->guardian_relation); ?> </td>
                                                                    </tr>  
                                                                </tbody>
                                                            </table>  
                                                        </div>  
                                                    </div>
                                                </div> 

                                                <div class="col-md-4 text-right">
                                                    <h5>TO BE ACCOMPLISHED BY PERSONEL</h5> 
                                                    <div class="row">  
                                                        <table class="table  form-drisms">
                                                            <tbody>
                                                                <tr>      
                                                                    <td><label>O.R.No.</label></td> 
                                                                    <td class=""><?php echo e($val->orno); ?> </td>
                                                                </tr> 
                                                                <tr>
                                                                    <td><label>Amount Paid</label> </td>
                                                                    <td><?php echo e($val->amount_paid); ?></td>
                                                                </tr>   
                                                            </tbody>
                                                        </table>    
                                                    </div>
                                                </div> 
                                            </div> 

                                            <div class="row">  
                                                <div class="col-md-4" >
                                                    <table class="table table-borderless form-drisms">
                                                        <thead> 
                                                        </thead>
                                                        <tbody>
                                                            <tr>      
                                                                <th scope="row">Years of Experience: </th> 
                                                                <td>  <?php echo e($val->y_e); ?>  </td>
                                                            </tr>  
                                                        </tbody>
                                                    </table>   
                                                </div>
                                            </div>
                                            <div class="row">  
                                                <div class="col-md-12">  
                                                    <table class="table table-borderless form-drisms">
                                                        <tbody>
                                                            <tr>      
                                                                <td> <label>Signature: </label></td> 
                                                                <td><label>Assisted by: </label> </td>
                                                            </tr> 
                                                            <tr>
                                                                <td class=""><hr></td> 
                                                                <td class=""><hr></td>
                                                            </tr>   
                                                        </tbody>
                                                    </table>   
                                                    <div class="alert alert-danger">NOTE: REGISTRATION FEE OF P2000 IS NON-REFUNDABLE</div>
                                                </div>  
                                            </div>    
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    <?php else: ?>
                                        <?php echo $__env->make("admin/empty/empty", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>         
                                    <?php endif; ?> 
                            </div> 
                            <div class="col-md-6">
                                <div class="student-growth-chart mt-15">
                                    <button class="btn btn-primary" id="student-enrollment-record">Print</button>
                                </div>
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
        </div> 
    <?php else: ?> 
        <?php echo $__env->make("admin/empty/empty", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
    <?php endif; ?>

</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/student/theoretical.blade.php ENDPATH**/ ?>