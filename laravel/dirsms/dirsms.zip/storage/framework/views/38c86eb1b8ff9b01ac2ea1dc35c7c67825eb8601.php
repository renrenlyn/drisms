

<!-- add school -->
<div class="modal right fade" id="create" role="dialog" tabindex="-1">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button aria-label="Close" class="close" data-dismiss="modal" type="button"><span aria-hidden="true"><i class="mdi mdi-close-circle-outline"></i></span></button>
                <h4 class="modal-title" id="myModalLabel2">Add School</h4>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('school.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <p>A welcome email will be set and recepient will complete setup of their school account.</p>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-12"></div>
                        </div>
                        <label>School Name</label> 
                        <input 
                            class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                            name="name" 
                            placeholder="School Name"  
                            type="text"
                        >
                        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <label>Email Address</label> 
                                <input 
                                    type="email" 
                                    class="form-control" 
                                    data-parsley-trigger="change" 
                                    name="email" 
                                    placeholder="Email Address"  
                                > 
                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <div class="alert alert-danger">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <label>Phone Number</label> 
                                <input 
                                    class="form-control" 
                                    name="phone" 
                                    placeholder="Phone Number"  
                                    type="text"
                                > 
                                <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                                    <div class="alert alert-danger">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <label>Address</label> 
                                <input
                                    class="form-control" 
                                    name="address" 
                                    placeholder="Address"  
                                    type="text"
                                > 
                                <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
                                    <div class="alert alert-danger">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-12"> 
                                <input type="submit" value="Add School"  class="btn btn-primary btn-block"/>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div><!-- modal-content -->
    </div><!-- modal-dialog -->
</div><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/modal/school.blade.php ENDPATH**/ ?>