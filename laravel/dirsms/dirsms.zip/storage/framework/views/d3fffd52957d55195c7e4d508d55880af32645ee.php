 
<?php $__env->startSection('content'); ?>     
        <!-- Admin home page --> 
        <!-- sidebar --> 

<?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

<?php echo $__env->make("admin/modal/student", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

<!-- main content -->
<div class="main-content">
    <div class="page-header"> 
        <button type="button" class="btn btn-success btn-icon pull-right toggle-search">
            <i class=" mdi mdi-filter-outline"></i> 
            Filter & Search 
        </button>
        <h3>Students</h3>
    </div> 
    <!-- page content --> 
    <div class="row"> 
        <!-- search & Filter -->
        <div class="col-md-12 search-filter" style="display: none;">
            <div class="card">
                <form class="row" action="<?php echo e(route('student-search')); ?>" method="GET" role="search">
                    <div class="col-md-4">
                            <div class="form-group">
                            <label>Search Name, Email or Phone</label>
                            <input type="text" class="form-control" placeholder="Search Name, Email or Phone" name="search">
                            </div>
                    </div> 
                    <div class="col-md-2">
                            <div class="form-group">
                            <label for="email">Gender</label>
                            <select class="form-control" name="gender">
                                <option value="">Select Gender*</option>
                                <option value="">All</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                            </div>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-primary btn-icon btn-block btn-sm" type="submit">
                            <i class=" mdi mdi-filter-outline"></i> 
                            Search
                        </button>
                    </div>
                </form>
            </div>
        </div> 
    </div>
    
    <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
            <?php echo \Session::get('success'); ?> 
        </div>
    <?php endif; ?>   
    <?php if(\Session::has('error')): ?>
        <div class="alert alert-danger">
            <?php echo \Session::get('error'); ?> 
        </div>
    <?php endif; ?> 
    <div class="row">  

    <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <!-- user grid -->
        <div class="col-md-4">
            <div class="user-grid card">
                <div class="user-grid-pic">
                    <?php if( !empty($student->image_name) ): ?> 
                    <img src="<?php echo e(url('/images'). '/' .$student->image_name); ?> " class="img-responsive">    
                    <?php else: ?>
                    <img src="<?php echo e(url('assets/images/avatar.png')); ?> ">
                    <?php endif; ?>
                </div>
                <div class="user-grid-info">
                    <h5><?php echo e(ucfirst($student->fname)); ?> <?php echo e(ucfirst($student->lname)); ?></h5>
                    <p><?php echo e($student->courses); ?> </p>
                    <p><?php echo e($student->phone); ?></p>
                </div>
                <div class="row user-grid-buttons">

                    <div class="col-md-6">
                        <a 
                            class="btn btn-primary btn-block" 
                            href="<?php echo e(route('profiles.show',$student->username)); ?>">
                            
                            Profile
                        </a>
                    </div>
                    <div class="col-md-6">
                        <a class="btn btn-default btn-block" href="<?php echo e(route('dashboard.show', $student->username)); ?>">
                            Schedule
                        </a>
                    </div>
 
                    <div class="col-md-12 mt-2">
                   
                        <button class="btn btn-success btn-block"  <?php echo e($permission_status); ?> data-toggle="modal" data-target="#create<?php echo e($student->id); ?>" >
                            Update Payment
                        </button>

                    </div>
                </div>
                <!-- <div class="user-grid-class-left">
                    <p class="text-success"><i class=" mdi mdi-counter"></i> student completed Class(es) Completed</p>
                </div> -->
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
            <?php echo $__env->make("admin/empty/empty", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
        <?php endif; ?>
    </div>
</div>



    <?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <script>
     //Hide Payment Method
     $('.paymentmethod').hide();
     //Conditionally show payment method
     $('.amountpaid').on('keyup',function(){
        if($(this).val() > 0){
            $('.paymentmethod').show();
            $('.method').attr('required',true);
        } else {
            $('.paymentmethod').hide();
            $('.method').attr('required',false); 
        }
     });
   </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/students.blade.php ENDPATH**/ ?>