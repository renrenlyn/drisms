 
<?php $__env->startSection('content'); ?>     
        <!-- Admin home page --> 
        <!-- sidebar --> 

    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   


        
    <!-- main content -->
    <div class="main-content">
        <div class="page-header">
            <button type="button" class="btn btn-primary btn-icon pull-right ml-5 addbranch" <?php echo e($permission_status); ?> data-toggle="modal" data-target="#create"><i class=" mdi mdi-plus-circle-outline"></i> Add Branch </button>
            <h3>Branches</h3>
            <p>These are branches of your school. </p>
        </div>


        <!-- page content -->   
        <?php if(\Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo \Session::get('success'); ?> 
            </div>
        <?php endif; ?>   
        <?php if(\Session::has('error')): ?>
            <div class="alert alert-danger">
                <?php echo \Session::get('error'); ?> 
            </div>
        <?php endif; ?> 
        <div class="row">  
             <?php $__empty_1 = true; $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <!-- branch -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="school">
                            <div class="school-heading">
                                <div class="school-icon"><i class="mdi mdi-map-marker-multiple"></i></div>
                                <div class="school-details">
                                    <h5><?php echo e($branch->name); ?></h5>
                                    <span><?php echo e($branch->email); ?></span>
                                    <span>
                                        <?php if( !empty($branch->phone) ): ?> <?php echo e($branch->phone); ?> <?php else: ?> Phone not set <?php endif; ?>
                                    </span>
                                </div>
                            </div>
                            <div class="school-info">
                                <p>
                                    <span><i class="mdi mdi-account-convert"></i></span>
                                    <?php echo e($branch->students); ?> Active Students
                                </p>
                                <p>
                                    <span><i class="mdi mdi-account-multiple-outline"></i></span>
                                    <?php echo e($branch->instructors); ?> Instructors
                                </p>
                                <p>
                                    <span><i class="mdi mdi-car"></i></span>
                                    <?php echo e($branch->vehicles); ?> Vehicles
                                </p>
                                <p>
                                    <span><i class="mdi mdi-map"></i></span>
                                    <?php if( !empty($branch->address) ): ?> <?php echo e($branch->address); ?> <?php else: ?> Address not set <?php endif; ?>
                                </p>
                            </div>
                            <div class="school-footer">
                                <div class="dropdown pull-right">
                                        <span class="dropdown-toggle" data-toggle="dropdown">
                                            <i class="mdi mdi-dots-horizontal"></i> </span>
                                        <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                            <li role="presentation">
                                                <a 
                                                    data-toggle="modal" 
                                                    data-target="#update<?php echo e($branch->id); ?>"
                                                    href="#"
                                                    class="<?php echo e($permission_status); ?>"
                                                > 
                                                    <i class="mdi mdi-pencil"></i> 
                                                    Edit
                                                </a>
                                            </li>
                                          <li role="presentation">
                                                <a role="menuitem" 
                                                    href="" 
                                                    data-toggle="modal" 
                                                    data-target="#sendemail<?php echo e($branch->id); ?>"
                                                    class="<?php echo e($permission_status); ?> <?php echo e($permission_delete); ?>"
                                                >
                                            <i class="mdi mdi-email-outline"></i> Send Email</a></li>
                                            <li role="presentation">
                                                <a role="menuitem" 
                                                    href=""   
                                                    data-toggle="modal" 
                                                    data-target="#sendsms<?php echo e($branch->id); ?>"
                                                    class="<?php echo e($permission_status); ?> <?php echo e($permission_delete); ?>"
                                                > 
                                                <i class="mdi mdi-message-text-outline"></i> 
                                                Send SMS
                                                </a>
                                            </li>
                                            <li 
                                                role="presentation"
                                            >  
                                                <form id="deleteBranch<?php echo e($branch->id); ?>" action="<?php echo e(route('branch.destroy', $branch->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>  
                                                    <a  
                                                        href="#"  
                                                        class="branch_delete   <?php echo e($permission_status); ?> <?php echo e($permission_delete); ?>"  
                                                        rel="deleteBranch<?php echo e($branch->id); ?>"

                                                    >
                                                        <i class="mdi mdi-delete"></i> 
                                                        Delete
                                                    </a> 
                                                </form>

                                            </li>
                                          
                                        </ul>
                                </div> 
                                    <span class="badge badge-success">Current branch</span> 
                                    <a 
                                    href="" 
                                    class="send-to-server-click" 
                                    data="branchid:<?php echo e($branch->id); ?>|csrf-token:<?php echo e(csrf_token()); ?>" 
                                    url="<?php echo e(url('Branch@switch')); ?>" 
                                    loader="true"><span class="badge badge-primary pointer">Switch to branch</span></a> 
                            </div>
                        </div>
                    </div>
                </div> 
                
                <?php echo $__env->make("admin/sms/branch", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
                <?php echo $__env->make("admin/modified/branch", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                <?php echo $__env->make("admin/email/branch", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>  
              <?php echo $__env->make("admin/empty/empty", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
            <?php endif; ?>
        </div>
    </div>
 


 
    <?php echo $__env->make("admin/modal/branch", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
    <!-- update -->
    <div class="modal right fade" id="update" role="dialog" tabindex="-1">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button aria-label="Close" class="close" data-dismiss="modal" type="button"><span aria-hidden="true"><i class="mdi mdi-close-circle-outline"></i></span></button>
                    <h4 class="modal-title" id="myModalLabel2">Edit School</h4>
                </div>
                <div class="update-holder"></div>
            </div><!-- modal-content -->
        </div><!-- modal-dialog -->
    </div>
    <!-- end update -->





        <?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

    <script>
         $('.branch_delete').on('click touchstart', function(e){ 
            e.preventDefault();
            if(confirm("Are you sure to delete this? This Branch and all it's data will be deleted")){

                $branch_data = $(this).attr('rel');
                $('#'+$branch_data).submit();

            } 
        })

    //Send Email
    // $('.sendemail').on('click',function(){
    //   var email = $(this).attr('data-value');
    //   $('.schoolemail').val(email);
    // });
    // //Send SMS
    // $('.sendsms').on('click',function(){
    //   var phone = $(this).attr('data-value');
    //   $('.schoolphone').val(phone);
    // });
    // //Edit Branch
    // $('.editbranch').on('click',function(){
    //     var data = JSON.parse($(this).attr('data-scope'));
    //     $('#create .modal-title').text('Edit Branch');
    //     $('.submitbtn').text('Save changes');
    //     $('.branchform').attr('action', `<?php echo e(url('Branch@edit')); ?>${data.id}/`);
    //     $('.branchname').val(data.bname);
    //     $('.branchemail').val(data.bemail);
    //     $('.branchphone').val(data.bphone);
    //     $('.branchaddress').val(data.baddress);
    //     $('.branchcode').val(data.bcode);
    // });
    // //Add Branch
    // $('.addbranch').on('click',function(){
    //     $('#create .modal-title').text('Add Branch');
    //     $('.submitbtn').text('Add Branch');
    //     $('.branchform').attr('action',"<?php echo e(url('Branch@store')); ?>");
    //     $('.branchname').val('');
    //     $('.branchemail').val('');
    //     $('.branchphone').val('');
    //     $('.branchaddress').val('');
    //     $('.branchcode').val('');
    // });
   </script>
 
<?php $__env->stopSection(); ?>

 

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/branch.blade.php ENDPATH**/ ?>