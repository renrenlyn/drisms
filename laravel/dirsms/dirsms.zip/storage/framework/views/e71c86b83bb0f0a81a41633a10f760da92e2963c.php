 
<?php $__env->startSection('content'); ?>      
    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
<!-- main content -->
<div class="main-content">  
    <div class="page-header"> 
        <h3> Update Instructor <?php echo e($fleet->make); ?> Schedule</h3> 
        <small> <?php echo e($fleet->car_no); ?> <?php echo e($fleet->car_plate); ?> <?php echo e($fleet->model); ?> <?php echo e($fleet->model_year); ?> </small>
    </div> 

    <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
            <?php echo \Session::get('success'); ?> 
        </div>
    <?php endif; ?>   
    <?php if(\Session::has('error')): ?>
        <div class="alert alert-danger">
            <?php echo \Session::get('error'); ?> 
        </div>
    <?php endif; ?> 

    
    <?php if(\Session::has('not_exists')): ?>
        <div class="alert alert-danger">
            <?php echo \Session::get('not_exists'); ?> 
        </div>
    <?php endif; ?> 
    
    <div>
        <form action="<?php echo e(route('fleet.form.update', $fleet->id)); ?>" method="post">
            <?php echo csrf_field(); ?>  
            <?php echo method_field('PUT'); ?>
             
            <div class="form-group"> 
                <div class="row"> 

                    <div class="col-md-6"> 
                        <label>Time Start and Time End</label>
                        <select name="start_end" class="form-control" required="">
                            <option value="7:30 AM to 9:00 AM" <?php echo e($fleet->time_start_end == '7:30 AM to 9:00 AM' ? 'selected' : ''); ?> >7:30 AM to 9:00 AM</option>
                            <option value="10:00 AM to 11:30 AM" <?php echo e($fleet->time_start_end == '10:00 AM to 11:30 AM' ? 'selected' : ''); ?> >10:00 AM to 11:30 AM</option>
                            <option value="1:30 AM to 3:00 AM" <?php echo e($fleet->time_start_end == '1:30 AM to 3:00 AM' ? 'selected' : ''); ?>>1:30 AM to 3:00 AM</option>
                            <option value="3:00 AM to 4:30 AM" <?php echo e($fleet->time_start_end == '3:00 AM to 4:30 AM' ? 'selected' : ''); ?>>3:00 AM to 4:30 AM</option>
                        </select>
                    </div>   

                    <div class="col-md-6"> 
                        <label>Day</label> 
 
                        <?php if(!empty($fleet->day)): ?>
                            <?php $__currentLoopData = explode(',', $fleet->day); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                <?php echo e($day); ?> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?> 
 
                            <select class="form-control select2" name="day[]" multiple=""> 
                                <option value="Monday"  
                                <?php if(!empty($fleet->day)): ?>
                                    <?php $__currentLoopData = explode(', ', $fleet->day); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                        <?php echo e($day == "Monday" ? 'selected' : ''); ?> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> 
                                > 
                                Monday</option>
                                <option value="Tuesday"
                                <?php if(!empty($fleet->day)): ?>
                                    <?php $__currentLoopData = explode(', ', $fleet->day); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  

                                        <?php echo e($day == "Tuesday" ? 'selected' : ''); ?> 

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> 
                                >Tuesday</option>
                                <option value="Wednesday" 
                                <?php if(!empty($fleet->day)): ?>
                                    <?php $__currentLoopData = explode(', ', $fleet->day); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                        <?php echo e($day == "Wednesday" ? 'selected' : ''); ?> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> 
                                >Wednesday</option>
                                <option value="Thursday" 
                                <?php if(!empty($fleet->day)): ?>
                                    <?php $__currentLoopData = explode(', ', $fleet->day); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                        <?php echo e($day == "Thursday" ? 'selected' : ''); ?> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> 
                                >Thursday</option>
                                <option value="Friday"
                                <?php if(!empty($fleet->day)): ?>
                                    <?php $__currentLoopData = explode(', ', $fleet->day); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                        <?php echo e($day == "Friday" ? 'selected' : ''); ?> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> 
                                >Friday</option>
                                <option value="Saturday"
                                <?php if(!empty($fleet->day)): ?>
                                    <?php $__currentLoopData = explode(', ', $fleet->day); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                        <?php echo e($day == "Saturday" ? 'selected' : ''); ?> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> 
                                >Saturday</option>
                                <option value="Sunday"
                                <?php if(!empty($fleet->day)): ?>
                                    <?php $__currentLoopData = explode(', ', $fleet->day); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                        <?php echo e($day == "Sunday" ? 'selected' : ''); ?> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> 
                                >Sunday</option>
                            </select>
                    </div>  

                </div>  
            </div>
 
            <div class="form-group">
                
                <div class="row"> 
                    <div class="col-md-6"> 
                        <label>Start</label>
                        <input type="date" name="start" class="form-control"  required="" value="<?php echo e($fleet->start); ?>"/>
                    </div> 
                    <div class="col-md-6"> 
                        <label>End</label>
                        <input type="date" name="end" class="form-control"  required="" value="<?php echo e($fleet->end); ?>"/>
                    </div> 

                </div> 
            </div> 

            <div class="form-group"> 
                <div class="row">
                    <div class="col-md-6">
                        <label>Duration</label>
                        <input type="number" name="duration" class="form-control" placeholder="Duration" required="" value="<?php echo e($fleet->duration); ?>">
                    </div>
                    
                    <div class="col-md-6">
                        <label>Period</label>
                        <select name="period" class="form-control" required="">
                            <option value="Days" <?php echo e($fleet->period == "Days" ? 'selected' : ''); ?>>Days</option>
                            <option value="Weeks" <?php echo e($fleet->period == "Weeks" ? 'selected' : ''); ?>>Weeks</option>
                            <option value="Months" <?php echo e($fleet->period == "Months" ? 'selected' : ''); ?>>Months</option>
                        </select>
                    </div> 
                </div> 
            </div>
 
            <div class="form-group">
                <div class="row">
                    <div class="col-md-12"> 
                        <input type="submit" value="Update Instructor Schedule"  class="btn btn-primary "/>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div> 
    <?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

<script> 
       
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/modified/instructorFleetSchedule.blade.php ENDPATH**/ ?>