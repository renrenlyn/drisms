
<!-- modals -->
<div class="modal right fade" id="update<?php echo e($branch->id); ?>" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="mdi mdi-close-circle-outline"></i></span></button>
                    <h4 class="modal-title" id="myModalLabel2">Update Branch</h4>
                </div>

                <div class="modal-body">
                    <form action="<?php echo e(route('branch.update',  $branch->id)); ?>" method="POST" >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <p>Enter information of your new branch.</p>
         
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-12">
                                    <label>Branch Name</label>
                                    <input 
                                        type="text" 
                                        class="form-control" 
                                        placeholder="Branch Name" 
                                        name="name" 
                                        required=""
                                        value="<?php echo e($branch->name); ?>"
                                    > 
                                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                        <div class="alert alert-danger">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
                                </div>
                            </div>
                        </div>




                      <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <label>Email Address</label>
                                <input 
                                    type="email" 
                                    class="form-control" 
                                    placeholder="Email Address" 
                                    name="email" 
                                    required=""
                                    value="<?php echo e($branch->email); ?>"
                                >

                                
                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <div class="alert alert-danger">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
                            </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <label>Phone Number</label>
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    placeholder="Phone Number" 
                                    name="phone" 
                                    required="" 
                                    value="<?php echo e($branch->phone); ?>"
                                > 
                                <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                                    <div class="alert alert-danger">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
                            </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <label>Address</label>
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    placeholder="Address" 
                                    name="address" 
                                    required=""
                                    value="<?php echo e($branch->address); ?>"
                                    
                                >
                                <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
                                    <div class="alert alert-danger">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
                            </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <input 
                                    type="submit" 
                                    class="btn btn-primary btn-block" 
                                    value="Update Branch"
                                />
                            </div>
                        </div>
                      </div>
                    </form>
                </div>

            </div><!-- modal-content -->
        </div><!-- modal-dialog -->
    </div><!-- modal -->
<?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/modified/branch.blade.php ENDPATH**/ ?>