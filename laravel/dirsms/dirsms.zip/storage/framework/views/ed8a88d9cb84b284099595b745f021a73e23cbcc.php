 
<?php $__env->startSection('content'); ?>      
    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     

    <style>

        ul li{
            list-style: none;
        }
        .form-drisms tbody tr td{
            padding-top: 0px !important; 
            padding-bottom: 0px !important
        }
        .form-drisms tbody tr{
            background-color:white !important;
        }
    </style>


<div class="main-content"> 
    <div class="page-header"> 
        <h3>Your Schedule for fleet</h3>
    </div>  
    <!-- students growth -->
 
    <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
            <?php echo \Session::get('success'); ?> 
        </div>
    <?php endif; ?>   
    <?php if(\Session::has('error')): ?>
        <div class="alert alert-danger">
            <?php echo \Session::get('error'); ?> 
        </div>
    <?php endif; ?> 


    <div class="row">    
        <div class="col-md-12">  
                <table class="table table-striped">
                    <thead>
                        <tr>  
                            <th scope="col">No. </th>
                            <th scope="col">Instructor</th>
                            <th scope="col">Make and Model</th>
                            <th scope="col">Model Year</th>
                            <th scope="col">Car Number</th>
                            <th scope="col">Car Plate</th>
                            <th scope="col">Time Start & End</th> 
                            <th scope="col">Date Start</th>
                            <th scope="col">Date End</th>
                            <th scope="col">Days</th>
                            <th scope="col">Duration & Period</th>                                                           
                            <th scope="col">Action</th>                                                           
                        </tr>
                    </thead>
                    <tbody> 
                        
                        <?php $__empty_1 = true; $__currentLoopData = $fleet_schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        
                            <form action="<?php echo e(route('student.fleet.form.update', $val->id)); ?>" method="POST">

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <input type="hidden" name="_student_id" value="<?php echo e(Auth::user()->id); ?>" />
                                    <tr> 
                                        <td> <?php echo e($key + 1); ?> </td> 
                                        <td><?php echo e($val->fname); ?> <?php echo e($val->lname); ?></td> 
                                        <td><?php echo e($val->make); ?> <?php echo e($val->model); ?> </td>  
                                        <td><?php echo e($val->model); ?></td>  
                                        <td><?php echo e($val->car_no); ?></td>  
                                        <td><?php echo e($val->car_plate); ?></td>  
                                        <td><?php echo e($val->time_start_end); ?></td>  
                                        <td><?php echo e($val->start); ?></td> 
                                        <td><?php echo e($val->end); ?></td> 
                                        <td><?php echo e($val->day); ?></td> 
                                        <td><?php echo e($val->duration); ?> <?php echo e($val->period); ?></td>  
                                        <td>  <input type="submit" value="Register" class="btn btn-primary <?php if(!empty($single_fleet)): ?> disabled <?php endif; ?>"> </td>  
                                    </tr> 
                            
                            </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?> 
                    <tbody>
                </table> 


        </div>
    </div> 





</div>


<?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

<script> 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/student/schedule_practical.blade.php ENDPATH**/ ?>