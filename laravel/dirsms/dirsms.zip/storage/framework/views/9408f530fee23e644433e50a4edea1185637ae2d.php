 
<?php $__env->startSection('content'); ?>     
        <!-- Admin home page --> 
        <!-- sidebar -->  
    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
<!-- main content -->
<div class="main-content">
    <div class="page-header">

    <a href="<?php echo e(route('fleet.form.show', $fleet_single->id)); ?>" class="btn btn-primary btn-icon pull-right ml-5 " >
        <i class=" mdi mdi-plus-circle-outline"> 
        </i> 
        Add Schedule
    </a>
       
        <h3>Schedule for <?php echo e($fleet_single->make); ?> </h3> 
    </div>
 

    <!-- page content -->
    <div class="row">


        <?php if(!empty($fleets)): ?>
     
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Make</th>
                    <th scope="col">Car Number</th>
                    <th scope="col">Car Plate</th>
                    <th scope="col">Model</th>
                    <th scope="col">Model Year</th>
                    <th scope="col">Time start and Time end</th>
                    <th scope="col">Date Start</th>
                    <th scope="col">Date End</th>
                    <th scope="col">Day</th> 
                    <th scope="col">Duration</th> 
                    <th scope="col">Period</th> 
                    <th scope="col">Instructor</th>  
                    <th scope="col">Actions</th>  
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $fleets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <th scope="row"><?php echo e($key + 1); ?></th>
                        <td><?php echo e($val->make); ?></td> 
                        <td><?php echo e($val->car_no); ?></td> 
                        <td><?php echo e($val->car_plate); ?></td> 
                        <td>
                            <?php echo e($val->model); ?>  
                        </td> 
                        <td><?php echo e($val->model_year); ?></td> 
                        <td><?php echo e($val->time_start_end); ?></td> 
                        <td><?php echo e($val->start); ?></td> 
                        <td><?php echo e($val->end); ?></td> 
                        <td><?php echo e($val->day); ?></td>  
                        <td><?php echo e($val->duration); ?></td>  
                        <td><?php echo e($val->period); ?></td>   
                        <td><?php echo e($val->fname); ?> <?php echo e($val->lname); ?> </td>   
                        <td>   
                            <a   
                                href="<?php echo e(route('fleet.form.edit', $val->id)); ?>"
                                class="btn btn-primary"
                            >  
                                <i class="mdi mdi-pencil"></i>  
                            </a> 
                            <form id="deleteFleetSchedule<?php echo e($val->id); ?>" action="<?php echo e(route('fleet.form.delete', $val->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>  
                                <a  
                                    href="#"  
                                    class="btn btn-danger fs_delete " 
                                    rel="deleteFleetSchedule<?php echo e($val->id); ?>"
                                >
                                    <i class="mdi mdi-delete"></i>  
                                </a> 
                            </form>  

                        </td>  
                    </tr> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?> 
            <?php echo $__env->make("admin/empty/empty", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
        <?php endif; ?>

    </div>

</div>  

<?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<script>  
    $('.fs_delete').on('click touchstart', function(e){ 
        e.preventDefault();
        if(confirm("Are you sure to delete this Fleet schedule?")){ 
            $fleet_delete = $(this).attr('rel');
            $('#'+$fleet_delete).submit();
        } 
    })  
</script>

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/review/reviewFleetSchedule.blade.php ENDPATH**/ ?>