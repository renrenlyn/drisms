 
<?php $__env->startSection('content'); ?>     
        <!-- Admin home page --> 
        <!-- sidebar --> 

<?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

<?php echo $__env->make("admin/modal/course", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    

<!-- main content --> 
<div class="main-content"> 
    <div class="page-header">
        <button 
            type="button" 
            class="btn btn-primary btn-icon pull-right ml-5" 
            data-toggle="modal" 
            data-target="#create"

            <?php echo e($permission_status); ?>

            <?php echo e($permission_delete); ?>


            >
            <i class=" mdi mdi-plus-circle-outline"></i> 
            Add Course 
        </button>
        <h3>Courses</h3>
        <p>Manage courses offered on your school. </p>
    </div> 

    <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
            <?php echo \Session::get('success'); ?> 
        </div>
    <?php endif; ?>   
    <?php if(\Session::has('error')): ?>
        <div class="alert alert-danger">
            <?php echo \Session::get('error'); ?> 
        </div>
    <?php endif; ?> 
    <!-- page content -->
    <div class="row"> 
        <!-- course -->

        <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                
            <div class="col-md-4">
                <div class="card">
                    <div class="course">
                        <div class="course-image">
 
                            <?php if($course->image_name): ?>   
                                <img 
                                    src="<?php echo e(url('/images'). '/' .$course->image_name); ?> " 
                                    class="img-responsive"
                                >  
                            <?php else: ?>
                                <img 
                                    src="<?php echo e(url('/assets/images/avatar.png')); ?> " 
                                    class="img-responsive"
                                > 
                            <?php endif; ?>
                       
                        </div>

                    
                            <div class="course-info">
                                <div class="course-info-basic">
                                    <span class="badge badge-dark pull-right" data-toggle="tooltip" data-placement="top" title=""><i class="menu-icon mdi mdi-account-multiple-outline"></i></span>
                                    <a href=""><h5> <?php echo e($course->name); ?> </h5></a>
                                    <p><?php echo e($course->theory_classes); ?> theory classes  | <?php echo e($course->practical_classes); ?> practical Classes</p>
                                </div>
                                <div class="course-info-other">
                                    <h5 class="pull-right">money <?php echo e($course->price); ?> </h5>
                                    <span class="badge badge-primary">
                                        <i class="menu-icon mdi mdi-clock-fast"></i> 
                                        <?php echo e($course->duration); ?> || <?php echo e($course->period); ?>  
                                    </span>
                                </div>
                                <div class="course-info-more">
                                    <div class="dropdown pull-right">
                                        <span class="dropdown-toggle" data-toggle="dropdown">
                                            <i class="mdi mdi-dots-horizontal"></i> </span>
                                            <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                            <li role="presentation"><a role="menuitem" href=""> <i class="mdi mdi-eye"></i> View More</a></li>
                                            <!-- <li role="presentation"><a role="menuitem" href=""> <i class="mdi mdi-calendar-text"></i> Schedule</a></li> -->
                                            <li role="presentation">
                                                <a 
                                                    role="menuitem" 
                                                    href="#" 
                                                    data-toggle="modal" 
                                                    data-target="#update<?php echo e($course->id); ?>"
                                                    class="<?php echo e($permission_status); ?>"    
                                                    >
                                                
                                                    <i class="mdi mdi-pencil"></i> 
                                                    Edit
                                                </a>
                                            </li>
                                            
                                            <li role="presentation"> 
                                                <form id="deleteCourse<?php echo e($course->id); ?>" action="<?php echo e(route('course.destroy', $course->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>  
                                                    <a  
                                                        href=""
                                                        class="couse_delete <?php echo e($permission_status); ?> <?php echo e($permission_delete); ?>"  
                                                        rel="deleteCourse<?php echo e($course->id); ?>"    
                                                    >
                                                        <i class="mdi mdi-delete"></i> 
                                                        Delete
                                                    </a> 
                                                </form>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="course-instructors">
                                
                                        <div class="more-instructors" data-toggle="tooltip" data-placement="top" title=""> </div>
                                    </div>
                                </div>
                            </div> 
                    </div>
                </div>
            </div> 

            <?php echo $__env->make("admin/modified/course", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php echo $__env->make("admin/empty/empty", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
        <?php endif; ?>
    </div>
</div>  
 
        <?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
     <script>
         $('.couse_delete').on('click touchstart', function(e){ 
            e.preventDefault();
            if(confirm("Are you sure to delete this? This course and all it's data will be deleted")){

                $course_data = $(this).attr('rel');
                $('#'+$course_data).submit();
            } 
         })
       

     </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/course.blade.php ENDPATH**/ ?>