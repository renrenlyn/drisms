 
<?php $__env->startSection('content'); ?>      
    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
<!-- main content -->
<div class="main-content">  
    <div class="page-header"> 
       
        <h3><?php echo e($school->name); ?></h3>
    </div> 

    <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
            <?php echo \Session::get('success'); ?> 
        </div>
    <?php endif; ?>   
    <?php if(\Session::has('error')): ?>
        <div class="alert alert-danger">
            <?php echo \Session::get('error'); ?> 
        </div>
    <?php endif; ?> 
    
    <?php if(\Session::has('exist')): ?>
        <div class="alert alert-danger">
            <?php echo \Session::get('exist'); ?> 
        </div>
    <?php endif; ?> 

    <form action="<?php echo e(route('school.courseSchoolStore')); ?>" method="post">
        <?php echo csrf_field(); ?> 
        <input type="hidden" value="<?php echo e($id); ?>" name="school_id"/> 

        <div class="form-group"> 
            <div class="row"> 

                <div class="col-md-6"> 
                    <label>Time Start and Time End</label>
                    <select name="start_end" class="form-control" required="">
                        <option value="7:30 AM to 9:00 AM">7:30 AM to 9:00 AM</option>
                        <option value="10:00 AM to 11:30 AM">10:00 AM to 11:30 AM</option>
                        <option value="1:30 AM to 3:00 AM">1:30 AM to 3:00 AM</option>
                        <option value="3:00 AM to 4:30 AM">3:00 AM to 4:30 AM</option>
                    </select>
                </div>   

                <div class="col-md-6"> 
                    <label>Day</label>

                    <select class="form-control select2" name="day[]" multiple=""> 
                        <option value="Monday">Monday</option>
                        <option value="Tuesday">Tuesday</option>
                        <option value="Wednesday">Wednesday</option>
                        <option value="Thursday">Thursday</option>
                        <option value="Friday">Friday</option>
                        <option value="Saturday">Saturday</option>
                        <option value="Sunday">Sunday</option>
                    </select>
                </div>  

            </div>  
        </div>

        
        <div class="form-group">
            
            <div class="row"> 
                <div class="col-md-6"> 
                    <label>Start</label>
                    <input type="date" name="start" class="form-control"  required=""/>
                </div> 
                <div class="col-md-6"> 
                    <label>End</label>
                    <input type="date" name="end" class="form-control"  required=""/>
                </div> 

            </div> 
        </div>


        <div class="form-group"> 
            <div class="row">
                <div class="col-md-6">
                    <label>Duration</label>
                    <input type="number" name="duration" class="form-control" placeholder="Duration" required="">
                </div>
                
                <div class="col-md-6">
                    <label>Period</label>
                    <select name="period" class="form-control" required="">
                        <option value="Days">Days</option>
                        <option value="Weeks">Weeks</option>
                        <option value="Months">Months</option>
                    </select>
                </div> 
            </div> 
        </div>
 
        <div class="form-group">
            <div class="row">
                <?php if(!empty($courses)): ?>
                    <div class="col-md-3">
    
                        <label>Course</label>
                        <select class="form-control select2" name="course_id" id="select-course" required=""> 
                            <option value="">Select Course</option>  
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                <option value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?></option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>  
                    </div>  
                <?php else: ?>
                    <span class="alert alert-success">
                        <strong>Empty Course</strong>
                    </span> 
                <?php endif; ?>  

                <?php if(!empty($instructors)): ?>
                    <div class="col-md-3"> 
                        <label>Instructor</label>
                        <select class="form-control select2" name="instructor_id" id="select-instructor" required=""> 
                            <option value="">Select Instructors</option>  
                            <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                <option value="<?php echo e($instructor->id); ?>" <?php if($instructor->status == "Suspended" || $instructor->status == "Inactive"): ?> disabled <?php endif; ?> ><?php echo e($instructor->fname); ?> <?php echo e($instructor->lname); ?> (<?php echo e($instructor->status); ?>)</option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>  
                    </div>
                <?php else: ?>
                    <span class="alert alert-success">
                        <strong>Empty Instructors</strong>
                    </span> 
                <?php endif; ?>  
 
                <?php if(!empty($branches)): ?>
                <div class="col-md-3"> 
                    <label>Branch</label>
                    <select class="form-control select2" name="branch_id" id="select-branch" required=""> 
                        <option value="">Select Branch</option>  
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                            <option value="<?php echo e($branch->id); ?>"> <?php echo e($branch->name); ?> <?php echo e($branch->email); ?> <?php echo e($branch->address); ?></option>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </select>  
                </div>
                <?php else: ?>
                    <span class="alert alert-success">
                        <strong>Empty Branch</strong>
                    </span> 
                <?php endif; ?>   
            </div> 
        </div>   


        <div class="hidden" id="school-course-table" >
            <table class="table"> 
                <tbody>
                    <tr>
                        <th scope="row" >Course: </th>
                        <td class="sc-title"></td> 
                    </tr> 
                    <tr>
                        <th scope="row">Price</th>
                        <td class="sc-price"></td> 
                    </tr>  
                    <tr>
                        <th scope="row">Status</th>
                        <td class="sc-status"></td> 
                    </tr>
                </tbody>
            </table>
        </div> 

        <div class="form-group">
            <div class="row">
                <div class="col-md-12"> 
                    <input type="submit" value="Add Course"  class="btn btn-primary btn-block"/>
                </div>
            </div>
        </div>
    </form>

</div> 
    <?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

    <script>

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
        } 
    }); 


    $('#select-course').on('change', function(e){
        e.preventDefault();

       
        var data1 = $(this).val();
  
        var url = '<?php echo e(route("course.show", ":id")); ?>';
            url = url.replace(':id', data1);
 
        $.ajax({
            url: url,
            method: 'get', 
            data: {
                _token: '<?php echo e(csrf_token()); ?>' 
            },
            success: function(result){
                $('#school-course-table').removeClass('hidden');
                $('.sc-title').text(result.name); 
                $('.sc-price').text(result.price);
                $('.sc-status').text(result.status); 
            }
        }); 

    })


        
       
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/form/addSchoolCourse.blade.php ENDPATH**/ ?>