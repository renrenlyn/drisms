<style>
  .d-none{
    display: none;
  }
</style>

<aside>
        <div class="slimscroll-menu">
            <!-- close menu -->
            <a href="" class="close-aside"><i class="mdi mdi-close-circle-outline"></i></a>
            <!-- Branding --> 
            <div class="side-branding">
                <a href=""> 
                  <?php if(!empty($profile_pic)): ?>
                    <?php $__empty_1 = true; $__currentLoopData = $profile_pic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                      <img 
                          src="<?php echo e(url('/images'). '/' .$profile->image_name); ?> " 
                          class="img-responsive" 
                      >   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <img 
                          src="<?php echo e(url('/assets/images/avatar.png')); ?> " 
                          class="img-responsive" 
                      > 
                    <?php endif; ?>
                  <?php endif; ?> 
                </a>
            </div> 
            <!-- navigation -->
            <ul class="nav-parent">
                <li class="menu-label">Main</li> 


                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('dashboard')); ?>">
                      <i class="menu-icon mdi mdi-speedometer"></i>
                      <span class="menu-title">Dashboard</span>
                    </a>
                </li> 

                <?php if(Auth::user()->role == 'Admin' || Auth::user()->role == 'Staff'): ?>
                  <!-- <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(url('admin/schedule')); ?>">
                        <i class="menu-icon mdi mdi-calendar-text"></i>
                        <span class="menu-title">Scheduling</span>
                      </a>
                  </li> -->
                <?php endif; ?>
                
                <?php if(Auth::user()->role == 'Student'): ?>

<!-- 
                  <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('enrollment.form')); ?>">
                          <i class="menu-icon mdi mdi-calendar-text"></i>
                          <span class="menu-title">Registration Form</span>
                        </a>
                  </li> -->

                  
                <?php endif; ?>

                <li class="nav-item"> 
                    <a 
                        class="nav-link" 
                        style="position: relative;" 
                        href="<?php echo e(url('notification')); ?>"
                    >
                      <i class="menu-icon mdi mdi-bell-outline"></i> 
                      <span class="menu-title">Notification</span>  
                      <span class="badge badge-pill badge-danger" id="notification" style="position: absolute; left: 16px;"></span>
                    </a>  
                </li>
               
                <?php if(Auth::user()->role == 'Admin' || Auth::user()->role == 'Staff'): ?>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(url('admin/student')); ?>" >
                      
                        <i class="menu-icon mdi mdi-account-convert"></i>
                        <span class="menu-title">Students</span>
                      </a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(url('admin/instructor')); ?>">
                        <i class="menu-icon mdi mdi-account-multiple-outline"></i>
                        <span class="menu-title">Instructor</span>
                      </a>
                  </li>
                <?php endif; ?>
                
                <?php if(Auth::user()->role == 'Admin'  || Auth::user()->role == 'Staff'): ?>
                
                <li class="menu-label">School</li>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(url('admin/fleet')); ?>">
                        <i class="menu-icon mdi mdi-car-connected"></i>
                        <span class="menu-title">Fleet</span>
                      </a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(url('admin/branch')); ?>">
                        <i class="menu-icon  mdi mdi-access-point-network"></i>
                        <span class="menu-title">Branch</span>
                      </a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(url('admin/invoice')); ?>">
                        <i class="menu-icon  mdi mdi-file-chart"></i>
                        <span class="menu-title">Invoices</span>
                      </a>
                  </li>
               
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('communication')); ?>">
                      <i class="menu-icon  mdi mdi-message-text-outline"></i>
                      <span class="menu-title">Communication</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(Auth::user()->role == 'Admin'): ?>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(url('admin/staff')); ?>">
                        <i class="menu-icon  mdi mdi-account-edit"></i>
                        <span class="menu-title">Staff</span>
                      </a>
                  </li> 
                <?php endif; ?>
                <li class="menu-label">Account</li>
              
                <?php if(Auth::user()->role == 'Admin'  || Auth::user()->role == 'Staff'): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('admin/course')); ?>"> 
                      <i class="menu-icon mdi mdi-seal"></i>
                      <span class="menu-title">Courses</span>
                    </a>
                </li>
             
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('admin/school')); ?>" >
                      <i class="menu-icon mdi mdi-blur-radial"></i>
                      <span class="menu-title">School</span>
                    </a>
                </li>
              <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('settings')); ?>">
                      <i class="menu-icon mdi mdi-settings"></i>
                      <span class="menu-title">Setting</span>
                    </a>
                </li>

                <li class="nav-item"> 
                      <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                          onclick="event.preventDefault();
                          document.getElementById('logout-form').submit();">
                          <i class="menu-icon mdi mdi-logout"></i>
                          <?php echo e(__('Logout')); ?> 
                      </a> 
                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                          <?php echo csrf_field(); ?>
                      </form> 
                </li>
 
            </ul>
        </div>
    </aside><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/layouts/includes/sidebar.blade.php ENDPATH**/ ?>