<style>
    .modal.right.fade.show .modal-dialog{
        right: 50% !important; 
        width: 100%;
        height: 80%;
        top: 50%;
        transform: translate(50%, -50%) !important;
    }
</style>
<div class="modal right fade" id="notificationModal<?php echo e($notification->id); ?>" role="dialog">


        <div class="modal-dialog" role="document">
            <div class="modal-content"> 
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="mdi mdi-close-circle-outline"></i></span></button>
                    <h4 class="modal-title" id="myModalLabel2">Notification Preview </h4> 
                </div> 
                <div class="modal-body">
                     

                    <div class="card" style="height: 100%;"> 
                        <?php if($notification->image_name): ?> 
                            <img 
                                src="<?php echo e(url('/images'). '/' .$notification->image_name); ?> " 
                                class="img-responsive" 
                                style=""
                            >    
                        <?php else: ?> 
                            <div class="notification-icon bg-warning"> 
                                <i class="mdi mdi-account-plus"></i>  
                            </div>
                        <?php endif; ?>

                        <div class="card-body">

                            <p class="card-text"><?php echo $notification->message; ?> </p>
                           

                        </div>

                        <div class="card-footer">
                            <small><?php echo e(date('F j, Y h:ia', strtotime($notification->created_at))); ?></small>
                        </div>
                    </div>

                </div> 
            </div><!-- modal-content -->
        </div><!-- modal-dialog -->
      </div><!-- modal --> <?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/modal/notification.blade.php ENDPATH**/ ?>