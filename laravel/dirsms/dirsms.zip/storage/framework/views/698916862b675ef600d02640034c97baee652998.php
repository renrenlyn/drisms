 
<?php $__env->startSection('content'); ?>     
        <!-- Admin home page --> 
        <!-- sidebar --> 

    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
<!-- main content -->
<div class="main-content">
        <div class="page-header">
            <!-- <button type="button" class="btn btn-primary btn-icon pull-right ml-5" data-toggle="modal" data-target="#create"><i class=" mdi mdi-account-plus-outline"></i> Add Instructor </button> -->
            <button type="button" class="btn btn-success btn-icon pull-right toggle-search"><i class=" mdi mdi-filter-outline"></i> Filter & Search </button>
            <h3>Instructors</h3>
        </div> 
        <!-- page content --> 
        <div class="row">
            <!-- search & Filter -->
            <div class="col-md-12 search-filter" style="display: none;">
               <div class="card">
                <form class="form" action="<?php echo e(route('instructor-search')); ?>" method="POST">
                    <div class="row">
                        <div class="col-md-8">
                              <div class="form-group">
                                <label>Search Name</label>
                                <input type="text" class="form-control" placeholder="Search Name, Email or Phone" name="search">
                              </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                            <label for="email">Gender</label>
                            <select class="form-control" name="gender">
                                <option value="">Select Gender*</option>
                                <option value="">All</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                              <button class="btn btn-primary btn-icon btn-block"><i class=" mdi mdi-filter-outline"></i> Search</button>
                        </div>
                    </div>
                </form>
              </div>
            </div> 
        </div>
        <div class="row"> 
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <!-- user grid -->
                <div class="col-md-4">
                    <div class="user-grid card">
                        <div class="user-grid-pic">
                            <img src="<?php echo e(url('/images'). '/' .$user->image_name); ?> " class="img-responsive">  
                        
                        </div>
                        <div class="user-grid-info">
                            <h5><?php echo e(ucfirst($user->fname)); ?> <?php echo e(ucfirst($user->lname)); ?></h5>
                            <p><?php echo e($user->status); ?></p>
                            <p><?php echo e($user->phone); ?></p>
                        </div>
                        <div class="row user-grid-buttons">
                            <div class="col-md-6">
                                <a 
                                    class="btn btn-primary btn-block <?php if($user->status == 'Inactive' || $user->status == 'Suspended'): ?> disabled <?php endif; ?>" 
                                    href="<?php echo e(route('profiles.show', $user->username)); ?>"
                                >Profile</a>
                            </div>
                            <div class="col-md-6">
                                <a class="btn btn-default btn-block <?php if($user->status == 'Inactive' || $user->status == 'Suspended'): ?> disabled <?php endif; ?>" href="<?php echo e(route('schedule.show', $user->id)); ?>">Schedule</a>
                            </div>
                            <div class="col-md-12 mt-2">
                                <button class="btn btn-success btn-block" <?php echo e($permission_status); ?> data-toggle="modal" data-target="#create<?php echo e($user->id); ?>"  >Update</button>
                            </div>
                        </div>
                        <!-- <div class="user-grid-class-left">
                            <p class="text-success"><i class=" mdi mdi-counter"></i> instructor completed Class(es) Completed</p>
                        </div> -->
                    </div>
                </div>

                <?php echo $__env->make("admin/modal/instructor", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php echo $__env->make("admin/empty/empty", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
            <?php endif; ?> 
        </div>
    </div>

    <?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/instructor.blade.php ENDPATH**/ ?>