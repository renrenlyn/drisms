 
<?php $__env->startSection('content'); ?>     
        <!-- Admin home page --> 
        <!-- sidebar --> 

    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

    <!-- main content -->
    <div class="main-content">
        <div class="page-header">
            <h3>Settings</h3> 

              
            <?php if( \Session::has('success')): ?>
                <div class="alert alert-success mt-3">
                    <?php echo \Session::get('success'); ?>

                </div>
            <?php endif; ?>
            <?php if( \Session::has('error')): ?>
                <div class="alert alert-danger mt-3"> 
                    <?php echo \Session::get('error'); ?> 
                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div> 
        <!-- page content -->
        <div class="row">
            <div class="col-md-12">
                <div class="card settings-card"> 
                        <ul class="nav nav-tabs">
                            <li><a data-toggle="tab" href="#step-1" class="active mr-3">Update Profile Info</a></li>
                            <li><a data-toggle="tab" href="#step-2" class="mr-3">Update Account</a></li> 
                            <li><a data-toggle="tab" href="#step-3" class="mr-3">Configure Your SMS Gateway</a></li> 
                         
                        </ul> 


                    <div class="row">

                        <div class="col-md-12">
                            <div class="tab-content">  
 
                                <!-- Step-1  -->
                                <div id="step-1" class="tab-pane fade in show active">
                                  
                                <p class="mt-3">Update your personal profile here.</p>
                                    <form method="POST" action="<?php echo e(route('settings.update', Auth::user()->id)); ?>" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label>Upload Profile</label>
                                                    <input type="file" name="profile_image" class="croppie" placeholder="Course Cover Image" crop-width="400" crop-height="190" accept="image/*" >
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row"> 
                                            <div class="col-md-6">
                                                <label for="fname" class="col-form-label text-md-right"><?php echo e(__('First Name')); ?></label>
                                                <input id="fname" type="text" class="form-control <?php if ($errors->has('fname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="fname" value="<?php echo e(Auth::user()->fname); ?>"  autocomplete="fname" autofocus>
                                                <?php if ($errors->has('fname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fname'); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        
                                            <div class="col-md-6">
                                                <label for="lname" class="col-form-label text-md-right"><?php echo e(__('Last Name')); ?></label>
                                                <input id="lname" type="text" class="form-control <?php if ($errors->has('lname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="lname" value="<?php echo e(Auth::user()->lname); ?>"  autocomplete="lname" autofocus>
                                                <?php if ($errors->has('lname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lname'); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <div class="col-md-6"> 
                                                <label for="address" class="col-form-label text-md-right"><?php echo e(__('Address')); ?></label>
                                                <input id="address" type="text" class="form-control <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="address" value="<?php echo e(Auth::user()->address); ?>"  autocomplete="address" autofocus>
                                                <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="dob" class="col-form-label text-md-right"><?php echo e(__('Date of Birth')); ?></label>
                                                <input id="dob" type="date" class="form-control <?php if ($errors->has('dob')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dob'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="dob" value="<?php echo e(Auth::user()->dob); ?>"  autocomplete="dob" autofocus>
                                                <?php if ($errors->has('dob')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dob'); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div> 
                                        </div>

                                        <div class="form-group row">
                                            <div class="col-md-6"> 
                                                <label for="phone" class="col-form-label text-md-right"><?php echo e(__('Phone')); ?></label>
                                                <input id="phone" type="text" class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="phone" value="<?php echo e(Auth::user()->phone); ?>"  autocomplete="phone" autofocus placeholder="Tell or Phone number">
                                                <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
  
                                            <div class="col-md-6">
                                                <label class="col-form-label text-md-right">Gender</label>
                                                <div>  
                                                    <div class="form-check">
                                                        <div class="d-flex justify-content-start">
                                                            <div class="d-inline">
                                                                <input id="male" <?php if(Auth::user()->gender =='Male'): ?> checked <?php endif; ?>  type="radio" class=" <?php if ($errors->has('gender')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gender'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="gender" value="Male"  autocomplete="gender" autofocus>
                                                                <label class="form-check-label" for="male">
                                                                    <?php echo e(__('Male')); ?>

                                                                </label>
                                                            </div>
                                                            <div class="d-inline ml-4">
                                                                <input id="female" <?php if(Auth::user()->gender =='Female'): ?> checked <?php endif; ?>  type="radio" class=" <?php if ($errors->has('gender')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gender'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="gender" value="Female"  autocomplete="gender" autofocus>
                                                                <label class="form-check-label" for="female">
                                                                    <?php echo e(__('Female')); ?>

                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php if ($errors->has('gender')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gender'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>  
                                        </div> 
                                        <div class="form-group row">
                                        </div>
                                        <div class="form-group row mb-0">
                                            <div class="col-md-6 offset-md-4">
                                                <button type="submit" class="btn btn-primary" name="step" value="step 1">
                                                    <?php echo e(__('Update Account')); ?>

                                                </button> 
                                            </div> 
                                        </div> 
                                    </form> 
                                </div>  


                                <!-- Step-2  -->

                                <div id="step-2" class="tab-pane fade">
                                    
                                <p class="mt-3">Update your personal profile here.</p>
                                    <form method="POST" action="<?php echo e(route('settings.update', Auth::user()->id)); ?>" >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="form-group row">  
                                            <div class="col-md-6">
                                                <label for="email" class="col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>
                                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(Auth::user()->email); ?>"  autocomplete="email">
                                            
                                            </div>
 
                                            <div class="col-md-6">
                                                <label for="username" class="col-form-label text-md-right"><?php echo e(__('Username')); ?></label>
                                                <input id="username" type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="username" value="<?php echo e(Auth::user()->username); ?>"  autocomplete="username">
                                             
                                            </div> 
                                        </div>
 
                                        <div class="form-group row">
                                            <div class="col-md-6">
                                                <label for="password" class="col-form-label text-md-right"><?php echo e(__('Password')); ?></label>
                                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password"  autocomplete="new-password">
                                               
                                            </div>
                                            <div class="col-md-6">
                                                <label for="password-confirm" class="col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>
                                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation"  autocomplete="new-password">
                                            </div>
                                        </div>

                                        
                                        <div class="form-group row">
                                        </div>
                                        <div class="form-group row mb-0">
                                            <div class="col-md-6 offset-md-4">
                                                <button type="submit" class="btn btn-primary" name="step" value="step 2">
                                                    <?php echo e(__('Update Account')); ?>

                                                </button> 
                                            </div> 
                                        </div>
                                
                                    </form> 
                                </div>



                                
                                <!-- Step-3  -->
                                <div id="step-3" class="tab-pane fade">

                                    <p>
                                        We are using <a href="https://www.traccar.org/documentation/"> traccar sms gateway </a> you can check the decumentation for traccar sms gateway here.
                                         
                                    </p>    
                                    
                                    <p>
                                        Use this configuration to send sms to all users.     
                                    </p>
                                    <?php if(!$existSmsGateWay): ?>
                                    <ul>    
                                        <li>1. Install traccar sms gateway to your mobile phone </li>
                                        <li>2. Go to settings > gateway > start  </li>
                                        <li>3. Register your API key here and Local API</li>
                                        <li>4. Please avoid spacing if not required</li>
                                        <li>5. Make sure your sim card can send a text message </li>
                                    </ul>

                                    <form method="POST" action="<?php echo e(route('smsGateWay.store')); ?>" >
                                        <?php echo csrf_field(); ?> 
                                        <div class="form-group row">  
                                            <div class="col-md-6">
                                                <label for="api_key" class="col-form-label text-md-right"><?php echo e(__('Api Key')); ?></label>
                                                <input id="api_key" type="text" class="form-control <?php if ($errors->has('api_key')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('api_key'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="api_key"  autocomplete="api_key" require>
                                            
                                            </div>
 
                                            <div class="col-md-6">
                                                <label for="mobile_ip" class="col-form-label text-md-right"><?php echo e(__('Mobile IP')); ?></label>
                                                <input id="mobile_ip" type="text" class="form-control <?php if ($errors->has('mobile_ip')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile_ip'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="mobile_ip" autocomplete="mobile_ip" require>
                                             
                                            </div> 
                                        </div>  
                                        <div class="form-group row">
                                        </div>
                                        <div class="form-group row mb-0">
                                            <div class="col-md-6 offset-md-4">
                                                <button type="submit" class="btn btn-primary" >
                                                    <?php echo e(__('SMS GATEWAY')); ?>

                                                </button> 
                                            </div> 
                                        </div> 
                                    </form> 
                                    <?php else: ?>
                                        
                                        <p>
                                            Use this configuration to send sms to all users.     
                                        </p>
                                        <ul>    
                                            <li>1. Install traccar sms gateway to your mobile phone </li>
                                            <li>2. Go to settings > gateway > start  </li>
                                            <li>3. Update your API key here and Local API</li>
                                            <li>4. Please avoid spacing if not required</li>
                                            <li>5. Make sure your sim card can send a text message </li>
                                        </ul>
                                        <div> 
                                            <form method="POST" action="<?php echo e(route('smsGateWay.update', Auth::user()->id)); ?>" >
                                                <?php echo csrf_field(); ?> 
                                                <?php echo method_field('PUT'); ?>
                                                <div class="form-group row">  
                                                    <div class="col-md-6">
                                                        <label for="api_key" class="col-form-label text-md-right"><?php echo e(__('Api Key')); ?></label>
                                                        <input id="api_key" type="text" class="form-control <?php if ($errors->has('api_key')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('api_key'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="api_key"  autocomplete="api_key" require>
                                                    </div> 
                                                    <div class="col-md-6">
                                                        <label for="mobile_ip" class="col-form-label text-md-right"><?php echo e(__('Mobile IP')); ?></label>
                                                        <input id="mobile_ip" type="text" class="form-control <?php if ($errors->has('mobile_ip')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile_ip'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="mobile_ip" autocomplete="mobile_ip" require>
                                                    
                                                    </div> 
                                                </div>  
                                                <div class="form-group row">
                                                </div>
                                                <div class="form-group row mb-0">
                                                    <div class="col-md-6 offset-md-4">
                                                        <button type="submit" class="btn btn-primary" >
                                                            <?php echo e(__('SMS GATEWAY')); ?>

                                                        </button> 
                                                    </div> 
                                                </div> 
                                            </form> 
                                        </div>
                                    <?php endif; ?> 
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </div>
    </div>
 
    <?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/settings/settings.blade.php ENDPATH**/ ?>