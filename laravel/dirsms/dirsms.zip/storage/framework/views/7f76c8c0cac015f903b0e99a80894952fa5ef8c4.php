 
<?php $__env->startSection('content'); ?>     
        <!-- Admin home page --> 
        <!-- sidebar --> 

    <?php echo $__env->make("layouts/includes/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

  
    <!-- main content -->
    <div class="main-content">
        <div class="page-header">
            <h3>Invoices</h3>
        </div>


        <!-- page content -->
        <div class="row">
            <div class="col-md-12">
                <div class="card"> 
                        <div class="card-body p-0">
                            <div class="table-responsive longer">
                                <table class="table table-striped mb-0 mw-1000" id="data-table">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Student</th>
                                        <th>Ref</th>
                                        <th>Amount</th>
                                        <th>Paid</th>
                                        <th>Balance</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody> 

                                    <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
 
                                        <tr>
                                            <th scope="row"> </th>
                                            <td class="p-8">
                                                <?php if($invoice->image_name): ?>

                                                <img height="45px" 
                                                    src="<?php echo e(url('/images'). '/' .$invoice->image_name); ?> " 
                                                    class="img-responsive" 
                                                >   
                                                <?php else: ?>
                                                <img height="45px" 
                                                    src="<?php echo e(url('/assets/images/avatar.png')); ?> " 
                                                    class="img-responsive" 
                                                >  
                                                <?php endif; ?>

                                                <a href=""><strong><?php echo e($invoice->fname); ?> <?php echo e($invoice->lname); ?> </strong></a>
                                                <span class="communication-contact"><?php echo e($invoice->email); ?> </span>
                                            </td>
                                            <td><?php echo e($invoice->course_name); ?></td>
                                            <td><?php echo e($invoice->total_amount); ?></td>
                                            <td><?php echo e($invoice->price); ?></td>
                                            <td>
                                            <?php
                                                $balance = 0;
                                                $balance = ($invoice->total_amount) - ($invoice->price);
                                            ?> 
                                                <?php if($balance < 0): ?> 
                                                    <span class="badge badge-danger"><?php echo e($balance); ?></span>
                                                <?php else: ?> 
                                                    <span class="badge badge-success"><?php echo e($balance); ?></span> 
                                                <?php endif; ?> 
                                            </td>
                                            <td>
                                                <?php if($invoice->total_amount >= $invoice->price): ?>  
                                                    <span class="badge badge-danger">Paid </span>   
                                                <?php else: ?>  
                                                    <span class="badge badge-danger">Not Paid </span>  
                                                <?php endif; ?>
                                            </td>
                                            
                                            <td><?php echo e($invoice->created_at); ?></td>
                                            <td class="text-center">
                                                <!-- <a class="btn btn-primary btn-sm btn-icon" target="_blank" href=""><i class="mdi mdi-eye"></i> Preview</a> -->
                                                <div class="dropdown inline-block">
                                                        <button class="btn btn-default btn-sm btn-icofn dropdown-toggle" data-toggle="dropdown">
                                                            <i class="mdi mdi-dots-vertical"></i></button>
                                                        <ul class="dropdown-menu" role="menu" aria-labelledby="menu1"> 
                                                            <?php if($balance < 0): ?> 
                                                                <li role="presentation">
                                                                    <a role="menuitem" href="" input="invoice" modal="#addpayment<?php echo e($invoice->user_id); ?>" rel="print-payment-record<?php echo e($invoice->user_id); ?>" class="pass-data <?php echo e($permission_status); ?>" value="" > 
                                                                        <i class="mdi mdi-credit-card-plus"></i> 
                                                                        Add Payment
                                                                    </a>
                                                                </li>  
                                                            <?php endif; ?> 
                                                            <li role="presentation"> 
                                                                <a role="menuitem" href="<?php echo e(route('invoice.print', $invoice->user_id)); ?>" target="_blank"> 

                                                                <i class="mdi mdi-eye"></i> 
                                                                    <!-- <i class="mdi mdi-cloud-download"></i>  -->
                                                                    Print Preview
                                                                </a>
                                                            </li>  
                                                        </ul>
                                                </div>
                                                
                                            </td>
 

                                        </tr>  
 
                                            <?php echo $__env->make("admin/modal/invoice", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                                        <tr>
                                            <th class="text-center" colspan="8">It's empty here!</th>
                                        </tr> 
                                    <?php endif; ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                </div>
            </div> 
        </div>
    </div>


    <?php echo $__env->make('../layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <script>
        $(document).ready(function() {
 

 


            // $('#data-table').DataTable({
            //     dom: 'Bfrtip',
            //     buttons: [
            //         'copyHtml5',
            //         'excelHtml5',
            //         'csvHtml5'
            //     ]
            // });
        });
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/admin/invoice.blade.php ENDPATH**/ ?>