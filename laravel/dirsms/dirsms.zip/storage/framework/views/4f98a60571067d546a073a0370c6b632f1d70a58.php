Hello <strong><?php echo e($name); ?></strong>,
<p><?php echo e($body); ?></p><?php /**PATH D:\drisms_\drisms\laravel\dirsms\resources\views/emails/mail.blade.php ENDPATH**/ ?>